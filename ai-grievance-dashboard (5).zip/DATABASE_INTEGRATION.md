# Database Integration Guide

## Overview
The Grievance Classification System is now fully integrated with Supabase backend. All data is stored in a PostgreSQL database and fetched in real-time through API routes.

## Database Schema

### Tables Created:
1. **citizens** - Stores citizen information (name, phone, address, email)
2. **complaints** - Main grievance/complaint records with AI classification data
3. **complaint_history** - Tracks status changes and updates for each complaint
4. **officers** - Government officers managing complaints
5. **departments** - Government departments (Electricity, Water, Sanitation, etc.)
6. **ai_metrics** - AI model performance tracking

## Features Integrated

### 1. Register Complaint (Now with Database Saving)
- Citizens can register complaints through the dialog
- OTP verification is performed (demo mode shows OTP in UI)
- Complaint data is saved to Supabase immediately after registration
- Auto-generates complaint ID in format: GRV-{timestamp}-{randomcode}
- Creates initial complaint history entry

**Endpoint:** `POST /api/complaints/create`

### 2. Track Complaint (Live Database Lookup)
- Search complaints by ID
- Shows real complaint details from database
- Displays complete timeline/history of status changes
- Shows citizen information and assigned officer details

**Endpoint:** `GET /api/complaints/track?id={complaintId}`

### 3. Dashboard Statistics (Real-Time)
- **Total Complaints** - All registered complaints
- **Resolved Today** - Complaints marked as resolved
- **Awaiting Action** - Pending complaints
- **Urgent Priority** - High priority complaints

**Endpoint:** `GET /api/dashboard/stats`

### 4. Grievance Table (Live Data)
- Shows recent complaints from database
- Displays department, AI confidence score, status, priority
- Supports filtering by status/department
- Auto-formats dates (2 min ago, 8h ago, etc.)

**Endpoint:** `GET /api/complaints/list?status={status}&department={dept}&limit=50`

## How to Use

### Running Locally
```bash
pnpm dev
```

### Registering a Complaint
1. Click "Register Complaint" button in the header
2. Fill in citizen details (Step 1)
3. Wait for OTP (Step 2 - demo displays OTP in amber box)
4. Enter OTP and verify
5. Fill in complaint details with language auto-detection (Step 3)
6. Submit - complaint is saved to database with tracking ID

### Tracking a Complaint
1. Click "Track Complaint" button in the header
2. Enter the complaint ID (starts with GRV-)
3. View real-time status, timeline, and citizen details

### Dashboard
The main dashboard now displays:
- Real stats calculated from database queries
- Recent complaints fetched from database
- Department-wise breakdown
- AI metrics (updated from AI Gateway)

## API Documentation

### Create Complaint
**POST** `/api/complaints/create`
```json
{
  "citizenName": "John Doe",
  "phone": "9876543210",
  "address": "123 Main St, City",
  "email": "john@example.com",
  "subject": "Power outage in area",
  "description": "बिजली कटौती हो गई है",
  "category": "Electricity",
  "department": "Electricity",
  "priority": "high",
  "language": "Hindi"
}
```

### List Complaints
**GET** `/api/complaints/list?status=pending&limit=50`

Query Parameters:
- `status` - Filter by status (pending, in-progress, resolved)
- `department` - Filter by department
- `limit` - Number of records (default: 50)

### Track Complaint
**GET** `/api/complaints/track?id=GRV-123456`

Query Parameters:
- `id` - Complaint ID (e.g., GRV-123456)
- `trackingId` - Internal UUID if known

### Dashboard Stats
**GET** `/api/dashboard/stats`

Returns:
- Total complaints count
- Resolved complaints count
- Pending complaints count
- Urgent (high priority) complaints count
- Today's complaints count
- Department-wise breakdown

## Real-Time Data Flow

```
Citizen Registration → OTP Verification → API Call → Supabase Insert
                                                            ↓
                                                    Complaint Record Created
                                                    AI Confidence Generated
                                                    History Entry Added
                                                            ↓
Dashboard Fetches Stats → API Aggregates Data → Shows Real Numbers
                                                            ↓
Track Complaint Search → API Queries DB → Returns Live Status
```

## Testing the Integration

### Test Data Entry
1. Register a test complaint
2. Check that it appears in the dashboard
3. Copy the complaint ID from success message
4. Use "Track Complaint" to verify it's in database

### Test Filtering
1. Create multiple complaints with different statuses
2. Try filtering by department in the grievance table
3. Verify stats update in real-time

### Test API Directly
```bash
# Get all complaints
curl "http://localhost:3000/api/complaints/list"

# Search specific complaint
curl "http://localhost:3000/api/complaints/track?id=GRV-1234567890"

# Get dashboard stats
curl "http://localhost:3000/api/dashboard/stats"
```

## Notes
- OTP in demo mode is displayed in UI (for testing)
- In production, implement SMS/Email API
- Dashboard auto-refreshes data every 30 seconds
- All queries use Supabase RLS for security
- Complaint IDs are unique and auto-generated
