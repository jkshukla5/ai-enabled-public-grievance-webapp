# AI Grievance Classification System - Setup & Run Guide

## Build & Deployment Fixed ✅

The deployment error has been resolved. The issue was incorrect component imports in the AI Assistant page.

### What Was Fixed:
1. Corrected imports from `Header` → `DashboardHeader` and `Sidebar` → `DashboardSidebar`
2. Removed unnecessary layout wrapper divs that were causing JSX parsing errors
3. Created proper `layout.tsx` for the `/ai-assistant` route
4. Cleaned up all component exports to use correct names

### Build Status:
```
✓ Compiled successfully in 10.9s
✓ Generating static pages using 1 worker (33/33) in 747ms
```

## Running the Development Server

### Option 1: Using pnpm (Recommended)
```bash
cd /vercel/share/v0-project
pnpm dev
```

### Option 2: Using npm
```bash
npm run dev
```

### Option 3: Using yarn
```bash
yarn dev
```

The dev server will start on `http://localhost:3000`

## Features Available

### Core Features:
- Dashboard with government department statistics
- Multi-language support (12 Indian languages)
- Complaint registration with OTP verification
- Complaint tracking system
- Language detection and auto-translation

### AI-Powered Features (AI Gateway):
1. **AI Assistant** (`/ai-assistant`)
   - Complaint Classification - Auto-categorize to departments
   - Translation - Multi-language support with AI
   - Action Plan Generation - Step-by-step resolution strategies
   - Response Generation - Professional government responses

2. **API Endpoints**:
   - `/api/ai/classify-complaint` - Classification service
   - `/api/ai/translate` - Translation service
   - `/api/ai/action-plan` - Action plan generation
   - `/api/ai/generate-response` - Response generation

### Data Flows:
- All AI features stream responses using the AI SDK's streaming capabilities
- Real-time processing with loading states
- Error handling with user-friendly messages

## Environment Variables

The project automatically uses Vercel AI Gateway with zero API key setup needed (VERCEL_OIDC_TOKEN is used).

## Project Structure

```
/app
  /api/ai/           - AI-powered API routes
  /ai-assistant/     - AI Assistant dashboard page
  /overview/         - Overview pages
  /grievances/       - Grievance management pages
  /analytics/        - Analytics pages
  /departments/      - Department-specific pages
  /officers/         - Officer management pages
  /settings/         - Settings page

/components
  /dashboard/        - Dashboard components (header, sidebar)
  /ai/              - AI-specific components
  /ui/              - UI component library (shadcn)

/hooks
  /use-ai-features.ts - AI hooks for components

/lib
  /language-context.tsx - Multi-language support
  /otp-service.ts      - OTP verification
