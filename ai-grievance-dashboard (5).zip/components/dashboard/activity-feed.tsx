"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, CheckCircle, AlertCircle, RefreshCw, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"

const activities = [
  {
    icon: Brain,
    iconColor: "text-primary",
    iconBg: "bg-primary/10",
    message: "AI routed 23 complaints to Electricity Dept",
    time: "Just now",
  },
  {
    icon: CheckCircle,
    iconColor: "text-success",
    iconBg: "bg-success/10",
    message: "Water Supply complaint GRV-1238 resolved",
    time: "3 min ago",
  },
  {
    icon: User,
    iconColor: "text-info",
    iconBg: "bg-info/10",
    message: "Officer Sharma reviewed Roads complaint",
    time: "8 min ago",
  },
  {
    icon: AlertCircle,
    iconColor: "text-destructive",
    iconBg: "bg-destructive/10",
    message: "Urgent: Sewage overflow escalated to DC",
    time: "12 min ago",
  },
  {
    icon: RefreshCw,
    iconColor: "text-warning",
    iconBg: "bg-warning/10",
    message: "Hindi language model updated",
    time: "25 min ago",
  },
  {
    icon: Brain,
    iconColor: "text-primary",
    iconBg: "bg-primary/10",
    message: "Multilingual batch: 58 complaints processed",
    time: "32 min ago",
  },
]

export function ActivityFeed() {
  const { t } = useLanguage()
  
  return (
    <Card className="border-border h-full">
      <CardHeader className="pb-4">
        <CardTitle className="text-base font-medium">{t("activityFeed")}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-start gap-3">
              <div
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                  activity.iconBg
                )}
              >
                <activity.icon className={cn("w-4 h-4", activity.iconColor)} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">{activity.message}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {activity.time}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
