"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Globe, MapPin, Check, Settings2 } from "lucide-react"
import { useLanguage, languages, type Language } from "@/lib/language-context"
import { cn } from "@/lib/utils"

export function LanguageSwitcher() {
  const { currentLanguage, setLanguage, isAutoDetect, setAutoDetect, t, detectLocationLanguage } = useLanguage()
  const [showSettings, setShowSettings] = useState(false)

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang)
  }

  const handleAutoDetectToggle = (checked: boolean) => {
    setAutoDetect(checked)
    if (checked) {
      detectLocationLanguage()
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2 min-w-[100px]">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">{currentLanguage.nativeName}</span>
            <span className="sm:hidden">{currentLanguage.code.toUpperCase()}</span>
            {isAutoDetect && (
              <Badge variant="secondary" className="ml-1 text-[10px] px-1 py-0">
                Auto
              </Badge>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="flex items-center justify-between">
            <span>{t("language")}</span>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2"
              onClick={() => setShowSettings(true)}
            >
              <Settings2 className="w-3 h-3 mr-1" />
              <span className="text-xs">Settings</span>
            </Button>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          {/* Auto-detect toggle */}
          <div className="px-2 py-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="auto-detect" className="text-sm cursor-pointer">
                {t("locationBased")}
              </Label>
            </div>
            <Switch
              id="auto-detect"
              checked={isAutoDetect}
              onCheckedChange={handleAutoDetectToggle}
            />
          </div>
          
          <DropdownMenuSeparator />
          
          <DropdownMenuLabel className="text-xs text-muted-foreground">
            {t("manual")}
          </DropdownMenuLabel>
          
          <div className="max-h-[300px] overflow-y-auto">
            <DropdownMenuRadioGroup
              value={currentLanguage.code}
              onValueChange={(value) => {
                const lang = languages.find(l => l.code === value)
                if (lang) handleLanguageSelect(lang)
              }}
            >
              {languages.map((lang) => (
                <DropdownMenuRadioItem
                  key={lang.code}
                  value={lang.code}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-6 text-center font-mono text-xs text-muted-foreground">
                      {lang.code.toUpperCase()}
                    </span>
                    <span>{lang.nativeName}</span>
                    <span className="text-muted-foreground text-xs">({lang.name})</span>
                  </div>
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Language Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5" />
              Language Settings
            </DialogTitle>
            <DialogDescription>
              Configure your preferred language settings for the grievance portal.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Current Language */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Current Language</Label>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">
                    {currentLanguage.nativeName.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-medium">{currentLanguage.nativeName}</p>
                  <p className="text-xs text-muted-foreground">{currentLanguage.name}</p>
                </div>
                {isAutoDetect && (
                  <Badge variant="outline" className="ml-auto">
                    <MapPin className="w-3 h-3 mr-1" />
                    Auto-detected
                  </Badge>
                )}
              </div>
            </div>

            {/* Auto-detect Setting */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Location-based Detection</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically detect language based on your location
                  </p>
                </div>
                <Switch
                  checked={isAutoDetect}
                  onCheckedChange={handleAutoDetectToggle}
                />
              </div>
              
              {isAutoDetect && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => detectLocationLanguage()}
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Re-detect Location
                </Button>
              )}
            </div>

            {/* Language Selection Grid */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Select Language Manually</Label>
              <div className="grid grid-cols-2 gap-2 max-h-[200px] overflow-y-auto pr-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => handleLanguageSelect(lang)}
                    className={cn(
                      "flex items-center gap-2 p-2 rounded-lg border text-left transition-colors",
                      currentLanguage.code === lang.code
                        ? "border-primary bg-primary/5"
                        : "border-border hover:bg-secondary"
                    )}
                  >
                    <span className="text-lg">{lang.nativeName.charAt(0)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{lang.nativeName}</p>
                      <p className="text-xs text-muted-foreground truncate">{lang.name}</p>
                    </div>
                    {currentLanguage.code === lang.code && (
                      <Check className="w-4 h-4 text-primary shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
