"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronRight, ExternalLink, MoreHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/lib/language-context"
import { useComplaints } from "@/hooks/use-dashboard-data"
import { Skeleton } from "@/components/ui/skeleton"

export function GrievanceTable() {
  const { t } = useLanguage()
  const { complaints, loading } = useComplaints(undefined, undefined, 8)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-success/10 text-success border-success/20"
      case "in-progress":
        return "bg-info/10 text-info border-info/20"
      case "pending":
        return "bg-warning/10 text-warning border-warning/20"
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "bg-destructive/10 text-destructive border-destructive/20"
      case "medium":
        return "bg-warning/10 text-warning border-warning/20"
      case "low":
        return "bg-success/10 text-success border-success/20"
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20"
    }
  }

  const formatDate = (date: string) => {
    const d = new Date(date)
    const now = new Date()
    const diff = now.getTime() - d.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return "Just now"
    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    if (days < 7) return `${days}d ago`
    return d.toLocaleDateString()
  }

  if (loading) {
    return (
      <Card className="border-border">
        <CardHeader className="pb-0">
          <CardTitle className="text-base font-medium">
            {t("recentComplaints")}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-2">
            {Array(8).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border">
      <CardHeader className="pb-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">
            {t("recentComplaints")}
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary">
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="in-progress">In Progress</TabsTrigger>
            <TabsTrigger value="resolved">Resolved</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50">
                    <TableHead className="text-muted-foreground">ID</TableHead>
                    <TableHead className="text-muted-foreground">Subject</TableHead>
                    <TableHead className="text-muted-foreground">Department</TableHead>
                    <TableHead className="text-muted-foreground">AI Score</TableHead>
                    <TableHead className="text-muted-foreground">Status</TableHead>
                    <TableHead className="text-muted-foreground">Priority</TableHead>
                    <TableHead className="text-muted-foreground">Language</TableHead>
                    <TableHead className="text-muted-foreground">Time</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {complaints.map((complaint) => (
                    <TableRow key={complaint.id} className="border-border/50 hover:bg-sidebar/50">
                      <TableCell className="font-medium text-sm">
                        {complaint.complaint_id}
                      </TableCell>
                      <TableCell className="text-sm max-w-xs truncate">
                        {complaint.subject}
                      </TableCell>
                      <TableCell className="text-sm">
                        {complaint.department}
                      </TableCell>
                      <TableCell className="text-sm">
                        <Badge variant="secondary" className="font-normal">
                          {complaint.ai_confidence.toFixed(1)}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        <Badge
                          variant="outline"
                          className={cn(
                            "font-normal capitalize",
                            getStatusColor(complaint.status)
                          )}
                        >
                          {complaint.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        <Badge
                          variant="outline"
                          className={cn(
                            "font-normal capitalize",
                            getPriorityColor(complaint.priority)
                          )}
                        >
                          {complaint.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-normal text-xs">
                          {complaint.language}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(complaint.created_at)}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {complaints.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No complaints found
              </div>
            )}
          </TabsContent>
          <TabsContent value="pending">
            <div className="text-center py-8 text-muted-foreground">
              Showing pending complaints awaiting department action
            </div>
          </TabsContent>
          <TabsContent value="in-progress">
            <div className="text-center py-8 text-muted-foreground">
              Showing complaints being processed by departments
            </div>
          </TabsContent>
          <TabsContent value="resolved">
            <div className="text-center py-8 text-muted-foreground">
              Showing resolved citizen complaints
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
