"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useLanguage } from "@/lib/language-context"

const categories = [
  { name: "Electricity", count: 312, percentage: 25.0, color: "bg-chart-2" },
  { name: "Water Supply", count: 287, percentage: 23.0, color: "bg-chart-5" },
  { name: "Roads & Infrastructure", count: 245, percentage: 19.6, color: "bg-chart-4" },
  { name: "Public Services", count: 205, percentage: 16.4, color: "bg-chart-3" },
  { name: "Sanitation", count: 198, percentage: 15.9, color: "bg-chart-1" },
]

export function ClassificationStats() {
  const { t } = useLanguage()
  
  return (
    <Card className="border-border">
      <CardHeader className="pb-4">
        <CardTitle className="text-base font-medium">
          {t("departmentClassification")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {categories.map((category) => (
          <div key={category.name} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-foreground">{category.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">{category.count}</span>
                <span className="text-foreground font-medium w-12 text-right">
                  {category.percentage}%
                </span>
              </div>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div
                className={`h-full ${category.color} rounded-full transition-all`}
                style={{ width: `${category.percentage}%` }}
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
