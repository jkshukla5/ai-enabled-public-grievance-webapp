"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  FileText,
  CheckCircle,
  Clock,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { useDashboardData } from "@/hooks/use-dashboard-data"
import { Skeleton } from "@/components/ui/skeleton"
import { cn } from "@/lib/utils"

export function StatsCards() {
  const { t } = useLanguage()
  const { stats, loading } = useDashboardData()

  const statConfigs = [
    {
      labelKey: "totalComplaints",
      value: stats?.totalComplaints || 0,
      change: "+18.3%",
      trend: "up",
      icon: FileText,
      color: "text-chart-1",
      bgColor: "bg-chart-1/10",
    },
    {
      labelKey: "resolvedToday",
      value: stats?.resolved || 0,
      change: "+12.5%",
      trend: "up",
      icon: CheckCircle,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      labelKey: "awaitingAction",
      value: stats?.pending || 0,
      change: "-8.2%",
      trend: "down",
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
    {
      labelKey: "urgentPriority",
      value: stats?.urgent || 0,
      change: "+3",
      trend: "up",
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
  ]

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array(4).fill(0).map((_, i) => (
          <Card key={i} className="border-border">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-3 w-32" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statConfigs.map((stat) => (
        <Card key={stat.labelKey} className="border-border">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">{t(stat.labelKey)}</p>
                <p className="text-2xl font-semibold text-foreground">
                  {typeof stat.value === 'number' ? stat.value.toLocaleString() : stat.value}
                </p>
                <div className="flex items-center gap-1 text-xs">
                  {stat.trend === "up" ? (
                    <TrendingUp className={cn("w-3 h-3", stat.labelKey === "urgentPriority" ? "text-destructive" : "text-success")} />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-success" />
                  )}
                  <span className={cn(
                    stat.trend === "up" && stat.labelKey !== "urgentPriority" ? "text-success" : 
                    stat.trend === "down" ? "text-success" : "text-destructive"
                  )}>
                    {stat.change}
                  </span>
                  <span className="text-muted-foreground">vs last week</span>
                </div>
              </div>
              <div className={cn("p-2.5 rounded-lg", stat.bgColor)}>
                <stat.icon className={cn("w-5 h-5", stat.color)} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
