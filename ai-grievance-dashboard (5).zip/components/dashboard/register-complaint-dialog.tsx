"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Plus,
  Languages,
  Sparkles,
  CheckCircle,
  Loader2,
  MapPin,
  Phone,
  User,
  FileText,
  Building2,
  AlertCircle,
  Lock,
  Send,
  Clock,
} from "lucide-react"
import { sendOTP, verifyOTP, resendOTP, clearOTPSession, generateOTP } from "@/lib/otp-service"

interface DetectedLanguage {
  code: string
  name: string
  confidence: number
}

const languageMap: Record<string, string> = {
  en: "English",
  hi: "Hindi",
  bn: "Bengali",
  te: "Telugu",
  mr: "Marathi",
  ta: "Tamil",
  gu: "Gujarati",
  kn: "Kannada",
  ml: "Malayalam",
  pa: "Punjabi",
  or: "Odia",
  as: "Assamese",
}

// Simulated language detection based on text patterns
function detectLanguage(text: string): DetectedLanguage {
  if (!text || text.length < 3) {
    return { code: "en", name: "English", confidence: 0 }
  }

  // Check for Hindi characters (Devanagari)
  const hindiPattern = /[\u0900-\u097F]/
  if (hindiPattern.test(text)) {
    return { code: "hi", name: "Hindi", confidence: 95 }
  }

  // Check for Bengali characters
  const bengaliPattern = /[\u0980-\u09FF]/
  if (bengaliPattern.test(text)) {
    return { code: "bn", name: "Bengali", confidence: 94 }
  }

  // Check for Telugu characters
  const teluguPattern = /[\u0C00-\u0C7F]/
  if (teluguPattern.test(text)) {
    return { code: "te", name: "Telugu", confidence: 93 }
  }

  // Check for Tamil characters
  const tamilPattern = /[\u0B80-\u0BFF]/
  if (tamilPattern.test(text)) {
    return { code: "ta", name: "Tamil", confidence: 94 }
  }

  // Check for Gujarati characters
  const gujaratiPattern = /[\u0A80-\u0AFF]/
  if (gujaratiPattern.test(text)) {
    return { code: "gu", name: "Gujarati", confidence: 93 }
  }

  // Check for Marathi (uses Devanagari but with specific words)
  const marathiPattern = /[\u0900-\u097F]/
  if (marathiPattern.test(text)) {
    return { code: "mr", name: "Marathi", confidence: 90 }
  }

  // Default to English
  return { code: "en", name: "English", confidence: 92 }
}

// Simulated translation
function translateToEnglish(text: string, fromLang: string): string {
  if (fromLang === "en") return text

  // Simulated translations for demo
  const translations: Record<string, string> = {
    "बिजली नहीं आ रही है": "There is no electricity supply",
    "पानी की समस्या": "Water problem",
    "सड़क खराब है": "Road is damaged",
    "कचरा नहीं उठाया जा रहा": "Garbage is not being collected",
    "नाला भरा हुआ है": "Drain is blocked",
    "स्ट्रीट लाइट खराब है": "Street light is not working",
  }

  // Check if we have a translation
  for (const [hindi, english] of Object.entries(translations)) {
    if (text.includes(hindi)) {
      return text.replace(hindi, english)
    }
  }

  return `[Translated from ${languageMap[fromLang] || fromLang}]: ${text}`
}

// AI-based department suggestion
function suggestDepartment(text: string): string {
  const lowerText = text.toLowerCase()
  
  if (lowerText.includes("electricity") || lowerText.includes("power") || lowerText.includes("बिजली") || lowerText.includes("light")) {
    return "electricity"
  }
  if (lowerText.includes("water") || lowerText.includes("पानी") || lowerText.includes("supply") || lowerText.includes("pipe")) {
    return "water"
  }
  if (lowerText.includes("garbage") || lowerText.includes("कचरा") || lowerText.includes("waste") || lowerText.includes("drain") || lowerText.includes("नाला")) {
    return "sanitation"
  }
  if (lowerText.includes("road") || lowerText.includes("सड़क") || lowerText.includes("pothole") || lowerText.includes("footpath")) {
    return "roads"
  }
  return "public-services"
}

export function RegisterComplaintDialog() {
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(1) // 1: Personal Info, 2: OTP Verification, 3: Complaint Details
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDetecting, setIsDetecting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [generatedId, setGeneratedId] = useState("")

  // Form fields
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [department, setDepartment] = useState("")
  const [subject, setSubject] = useState("")
  const [description, setDescription] = useState("")
  const [priority, setPriority] = useState("medium")

  // OTP fields
  const [otp, setOtp] = useState("")
  const [otpMessage, setOtpMessage] = useState("")
  const [otpError, setOtpError] = useState("")
  const [isSendingOTP, setIsSendingOTP] = useState(false)
  const [isVerifyingOTP, setIsVerifyingOTP] = useState(false)
  const [otpResendTimer, setOtpResendTimer] = useState(0)
  const [phoneVerified, setPhoneVerified] = useState(false)
  const [demoOTP, setDemoOTP] = useState("") // For demo purposes

  // Language detection
  const [detectedLanguage, setDetectedLanguage] = useState<DetectedLanguage>({
    code: "en",
    name: "English",
    confidence: 0,
  })
  const [translatedText, setTranslatedText] = useState("")
  const [showTranslation, setShowTranslation] = useState(false)

  // Auto-detect language when description changes
  useEffect(() => {
    if (description.length > 5) {
      setIsDetecting(true)
      const timer = setTimeout(() => {
        const detected = detectLanguage(description)
        setDetectedLanguage(detected)
        
        if (detected.code !== "en" && detected.confidence > 80) {
          const translated = translateToEnglish(description, detected.code)
          setTranslatedText(translated)
          setShowTranslation(true)
        } else {
          setShowTranslation(false)
        }

        // Auto-suggest department
        const suggestedDept = suggestDepartment(description)
        if (!department) {
          setDepartment(suggestedDept)
        }

        setIsDetecting(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [description, department])

  // OTP Resend timer
  useEffect(() => {
    if (otpResendTimer > 0) {
      const timer = setTimeout(() => setOtpResendTimer(otpResendTimer - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [otpResendTimer])

  const handleSendOTP = async () => {
    if (!phone) {
      setOtpError("Please enter a valid phone number")
      return
    }

    setIsSendingOTP(true)
    setOtpError("")
    setOtpMessage("")
    setOtp("")

    try {
      const result = await sendOTP(phone)
      if (result.success) {
        // Store demo OTP for display
        setDemoOTP(result.otp || "")
        setOtpMessage(`✓ OTP sent to ${phone}`)
        setOtpResendTimer(60)
        console.log("[v0] OTP sent successfully. Demo OTP:", result.otp)
      } else {
        setOtpError("Failed to send OTP. Please try again.")
      }
    } catch (error) {
      setOtpError("Error sending OTP. Please try again.")
      console.error("[v0] Error:", error)
    } finally {
      setIsSendingOTP(false)
    }
  }

  const handleVerifyOTP = async () => {
    if (!otp || otp.length !== 6) {
      setOtpError("Please enter a valid 6-digit OTP")
      return
    }

    setIsVerifyingOTP(true)
    setOtpError("")

    try {
      const result = verifyOTP(phone, otp)
      if (result.success) {
        setPhoneVerified(true)
        setOtpMessage("Phone number verified successfully!")
        setTimeout(() => {
          setStep(3)
        }, 1000)
      } else {
        setOtpError(result.message)
      }
    } catch (error) {
      setOtpError("Error verifying OTP. Please try again.")
    } finally {
      setIsVerifyingOTP(false)
    }
  }

  const handleResendOTP = async () => {
    setIsSendingOTP(true)
    setOtpError("")
    setOtp("")

    try {
      const result = await resendOTP(phone)
      if (result.success) {
        const newOtp = generateOTP()
        setDemoOTP(newOtp)
        setOtpMessage(`✓ ${result.message}`)
        setOtpResendTimer(60)
        console.log("[v0] OTP resent. New demo OTP:", newOtp)
      } else {
        setOtpError(result.message)
      }
    } catch (error) {
      setOtpError("Error resending OTP. Please try again.")
      console.error("[v0] Error:", error)
    } finally {
      setIsSendingOTP(false)
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      console.log('[v0] Submitting complaint with data:', {
        name,
        phone,
        address,
        subject,
        department,
      })

      const response = await fetch('/api/complaints/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          citizenName: name,
          phone,
          address,
          email,
          subject,
          description,
          category: department,
          department: department,
          priority,
          language: detectedLanguage.name,
        }),
      })

      console.log('[v0] Response status:', response.status)
      
      const data = await response.json()
      console.log('[v0] Response data:', data)
      
      if (response.ok && data.success) {
        setGeneratedId(data.complaintId)
        setShowSuccess(true)
        clearOTPSession(phone)
        console.log('[v0] Complaint registered successfully:', data.complaintId)
      } else {
        const errorMsg = data.error || data.details || 'Failed to register complaint'
        console.error('[v0] API Error:', errorMsg)
        alert(`Error: ${errorMsg}`)
      }
    } catch (error) {
      console.error('[v0] Error submitting complaint:', error)
      alert('Error registering complaint: ' + String(error))
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetForm = () => {
    setStep(1)
    setName("")
    setPhone("")
    setAddress("")
    setDepartment("")
    setSubject("")
    setDescription("")
    setPriority("medium")
    setOtp("")
    setOtpMessage("")
    setOtpError("")
    setPhoneVerified(false)
    setOtpResendTimer(0)
    setDetectedLanguage({ code: "en", name: "English", confidence: 0 })
    setTranslatedText("")
    setShowTranslation(false)
    setShowSuccess(false)
    setGeneratedId("")
  }

  const handleClose = () => {
    setOpen(false)
    setTimeout(resetForm, 300)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Register Complaint
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        {showSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-success/20 flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <DialogTitle className="text-xl">Complaint Registered Successfully</DialogTitle>
            <DialogDescription className="space-y-2">
              <p>Your complaint has been submitted and routed to the appropriate department.</p>
              <div className="mt-4 p-4 bg-secondary rounded-lg">
                <p className="text-sm text-muted-foreground">Your Tracking ID</p>
                <p className="text-2xl font-bold text-primary">{generatedId}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  Save this ID to track your complaint status
                </p>
              </div>
            </DialogDescription>
            <DialogFooter className="mt-6">
              <Button variant="outline" onClick={handleClose}>
                Close
              </Button>
              <Button onClick={resetForm}>
                Register Another
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Register New Complaint
              </DialogTitle>
              <DialogDescription>
                File a grievance with your local government. Our AI will automatically
                route it to the appropriate department.
              </DialogDescription>
            </DialogHeader>

            {/* Progress indicator */}
            <div className="flex items-center gap-2 mb-4">
              <div className="flex-1">
                <Progress value={step === 1 ? 33 : step === 2 ? 66 : 100} className="h-1" />
              </div>
              <span className="text-xs text-muted-foreground">Step {step} of 3</span>
            </div>

            {step === 1 ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5" />
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5" />
                    Mobile Number
                  </Label>
                  <Input
                    id="phone"
                    placeholder="+91 XXXXX XXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5" />
                    Address / Location
                  </Label>
                  <Textarea
                    id="address"
                    placeholder="Enter complete address with landmark"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="min-h-[80px]"
                  />
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={handleClose}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={() => setStep(2)}
                    disabled={!name || !phone || !address}
                  >
                    Next: Verify Phone
                  </Button>
                </DialogFooter>
              </div>
            ) : step === 2 ? (
              <div className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <div className="flex gap-3">
                    <Lock className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-sm text-blue-900 dark:text-blue-100">Phone Verification</p>
                      <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                        {demoOTP 
                          ? `OTP has been sent to ${phone}. See the demo OTP below.`
                          : `Click "Send OTP" to send a 6-digit verification code to ${phone}.`
                        }
                      </p>
                    </div>
                  </div>
                </div>

                {!demoOTP ? (
                  <Button 
                    onClick={handleSendOTP} 
                    disabled={isSendingOTP}
                    className="w-full"
                    size="lg"
                  >
                    {isSendingOTP ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Sending OTP...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send OTP to {phone}
                      </>
                    )}
                  </Button>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="otp" className="flex items-center gap-2">
                        <Lock className="w-3.5 h-3.5" />
                        Enter OTP
                      </Label>
                      <Input
                        id="otp"
                        placeholder="000000"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.slice(0, 6))}
                        maxLength={6}
                        disabled={phoneVerified}
                        className="text-center text-2xl tracking-widest font-mono"
                        autoFocus
                      />
                    </div>

                    {otpMessage && !otpError && (
                      <div className="text-sm text-success p-3 bg-success/10 rounded-lg border border-success/20">
                        {otpMessage}
                      </div>
                    )}

                    {demoOTP && (
                      <div className="bg-amber-50 dark:bg-amber-950 border-2 border-amber-200 dark:border-amber-800 rounded-lg p-4">
                        <p className="text-xs font-semibold text-amber-900 dark:text-amber-100 mb-2">
                          📱 Demo Mode - Copy OTP Below
                        </p>
                        <div className="bg-white dark:bg-slate-900 rounded-md p-4 mb-3 cursor-pointer hover:bg-amber-50 dark:hover:bg-slate-800 transition" onClick={() => {
                          navigator.clipboard.writeText(demoOTP)
                          setOtpMessage("✓ OTP copied to clipboard!")
                        }}>
                          <p className="text-center text-4xl font-bold tracking-widest font-mono text-amber-600 dark:text-amber-400">
                            {demoOTP}
                          </p>
                          <p className="text-xs text-center text-amber-700 dark:text-amber-300 mt-2">
                            Click to copy
                          </p>
                        </div>
                        <p className="text-xs text-amber-700 dark:text-amber-300">
                          In production, this OTP would be sent via SMS to your phone.
                        </p>
                      </div>
                    )}

                    {otpError && (
                      <div className="text-sm text-destructive p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                        {otpError}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs text-muted-foreground">
                        Didn&apos;t receive OTP?
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleResendOTP}
                        disabled={otpResendTimer > 0 || isSendingOTP}
                        className="text-primary h-auto p-0"
                      >
                        {otpResendTimer > 0 ? (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Resend in {otpResendTimer}s
                          </span>
                        ) : (
                          "Resend OTP"
                        )}
                      </Button>
                    </div>
                  </>
                )}

                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => {
                    setStep(1)
                    setDemoOTP("")
                    setOtp("")
                    setOtpMessage("")
                  }}>
                    Back
                  </Button>
                  <Button
                    onClick={handleVerifyOTP}
                    disabled={!otp || otp.length !== 6 || isVerifyingOTP || phoneVerified}
                  >
                    {isVerifyingOTP ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Verifying...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Verify OTP
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-success/10 border border-success/20 rounded-lg p-3">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span className="text-success font-medium">Phone verified - {phone}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject / Title</Label>
                  <Input
                    id="subject"
                    placeholder="Brief title of your complaint"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="flex items-center gap-2">
                    Complaint Details
                    {isDetecting && (
                      <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
                    )}
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your complaint in detail (you can write in Hindi or any regional language)"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="min-h-[120px]"
                  />
                  
                  {/* Language Detection Badge */}
                  {detectedLanguage.confidence > 0 && (
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <Badge variant="outline" className="gap-1.5">
                        <Languages className="w-3 h-3" />
                        {detectedLanguage.name}
                        <span className="text-muted-foreground">
                          ({detectedLanguage.confidence}%)
                        </span>
                      </Badge>
                      {detectedLanguage.code !== "en" && (
                        <Badge variant="secondary" className="gap-1.5">
                          <Sparkles className="w-3 h-3 text-primary" />
                          Auto-translated
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Translation Preview */}
                  {showTranslation && translatedText && (
                    <div className="mt-3 p-3 bg-secondary/50 rounded-lg border border-border">
                      <div className="flex items-center gap-2 mb-2">
                        <Languages className="w-4 h-4 text-primary" />
                        <span className="text-xs font-medium text-muted-foreground">
                          English Translation
                        </span>
                      </div>
                      <p className="text-sm text-foreground">{translatedText}</p>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <Building2 className="w-3.5 h-3.5" />
                      Department
                      {department && (
                        <Badge variant="secondary" className="text-[10px] gap-1">
                          <Sparkles className="w-2.5 h-2.5" />
                          AI Suggested
                        </Badge>
                      )}
                    </Label>
                    <Select value={department} onValueChange={setDepartment}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="electricity">Electricity</SelectItem>
                        <SelectItem value="water">Water Supply</SelectItem>
                        <SelectItem value="sanitation">Sanitation</SelectItem>
                        <SelectItem value="roads">Roads & Infrastructure</SelectItem>
                        <SelectItem value="public-services">Public Services</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Priority
                    </Label>
                    <Select value={priority} onValueChange={setPriority}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => setStep(2)}>
                    Back
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={!subject || !description || !department || isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Complaint
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
