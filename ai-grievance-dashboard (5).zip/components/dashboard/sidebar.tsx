"use client"

import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  FileText,
  BarChart3,
  Settings,
  Users,
  Brain,
  Building2,
  Bell,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Zap,
  Droplets,
  Trash2,
  Construction,
  Landmark,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  PieChart,
  LineChart,
  Target,
  Cpu,
  Languages,
  GitBranch,
  UserCog,
  Shield,
  FileSearch,
  ClipboardList,
  Calendar,
  Wand2,
  type LucideIcon,
} from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface SubMenuItem {
  icon: LucideIcon
  label: string
  href: string
}

interface NavItem {
  icon: LucideIcon
  label: string
  href?: string
  badge?: string
  subItems?: SubMenuItem[]
}

const navItems: NavItem[] = [
  { 
    icon: LayoutDashboard, 
    label: "Overview", 
    href: "/",
    subItems: [
      { icon: TrendingUp, label: "Dashboard", href: "/" },
      { icon: Clock, label: "Today Summary", href: "/overview/today" },
      { icon: Calendar, label: "Weekly Report", href: "/overview/weekly" },
    ]
  },
  { 
    icon: FileText, 
    label: "All Grievances", 
    badge: "1,247",
    subItems: [
      { icon: ClipboardList, label: "All Complaints", href: "/grievances/all" },
      { icon: Clock, label: "Pending", href: "/grievances/pending" },
      { icon: AlertTriangle, label: "Urgent", href: "/grievances/urgent" },
      { icon: CheckCircle, label: "Resolved", href: "/grievances/resolved" },
    ]
  },
  { 
    icon: Brain, 
    label: "AI Classification",
    subItems: [
      { icon: Cpu, label: "Model Status", href: "/ai/model-status" },
      { icon: Target, label: "Accuracy Report", href: "/ai/accuracy" },
      { icon: Languages, label: "Language Support", href: "/ai/languages" },
      { icon: GitBranch, label: "Routing Rules", href: "/ai/routing" },
    ]
  },
  { 
    icon: Wand2, 
    label: "AI Assistant",
    href: "/ai-assistant"
  },
  { 
    icon: BarChart3, 
    label: "Analytics",
    subItems: [
      { icon: PieChart, label: "Department Stats", href: "/analytics/departments" },
      { icon: LineChart, label: "Trends", href: "/analytics/trends" },
      { icon: TrendingUp, label: "Performance", href: "/analytics/performance" },
    ]
  },
  { 
    icon: Building2, 
    label: "Departments",
    subItems: [
      { icon: Zap, label: "Electricity", href: "/departments/electricity" },
      { icon: Droplets, label: "Water Supply", href: "/departments/water" },
      { icon: Trash2, label: "Sanitation", href: "/departments/sanitation" },
      { icon: Construction, label: "Roads & Infra", href: "/departments/roads" },
      { icon: Landmark, label: "Public Services", href: "/departments/public-services" },
    ]
  },
  { 
    icon: Users, 
    label: "Officers",
    subItems: [
      { icon: Users, label: "All Officers", href: "/officers/all" },
      { icon: UserCog, label: "Assign Duties", href: "/officers/assign" },
      { icon: Shield, label: "Permissions", href: "/officers/permissions" },
      { icon: FileSearch, label: "Performance", href: "/officers/performance" },
    ]
  },
]

const bottomItems = [
  { icon: Bell, label: "Notifications", badge: "3", href: "/notifications" },
  { icon: HelpCircle, label: "Help Center", href: "/help" },
  { icon: Settings, label: "Settings", href: "/settings" },
]

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const [expandedMenus, setExpandedMenus] = useState<string[]>(["Overview"])
  const pathname = usePathname()

  const toggleMenu = (label: string) => {
    setExpandedMenus((prev) =>
      prev.includes(label)
        ? prev.filter((item) => item !== label)
        : [...prev, label]
    )
  }

  const isActive = (href: string) => pathname === href
  const isParentActive = (subItems?: SubMenuItem[]) => 
    subItems?.some((item) => pathname === item.href)

  return (
    <aside
      className={cn(
        "bg-sidebar border-r border-sidebar-border flex flex-col h-screen transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <div className="flex items-center gap-3 p-4 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
          <Landmark className="w-5 h-5 text-primary-foreground" />
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="font-semibold text-sidebar-foreground text-sm">
              Jan Shikayat AI
            </span>
            <span className="text-xs text-muted-foreground">Govt. Portal</span>
          </div>
        )}
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <div className="text-xs font-medium text-muted-foreground mb-2 px-2">
          {!collapsed && "MAIN MENU"}
        </div>
        {navItems.map((item) => (
          <div key={item.label}>
            <button
              onClick={() => item.subItems && toggleMenu(item.label)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                isParentActive(item.subItems)
                  ? "bg-sidebar-accent text-sidebar-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}
            >
              <item.icon className="w-4 h-4 shrink-0" />
              {!collapsed && (
                <>
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.badge && (
                    <span className="px-2 py-0.5 text-xs rounded-full bg-primary/20 text-primary">
                      {item.badge}
                    </span>
                  )}
                  {item.subItems && (
                    <ChevronDown
                      className={cn(
                        "w-4 h-4 transition-transform",
                        expandedMenus.includes(item.label) && "rotate-180"
                      )}
                    />
                  )}
                </>
              )}
            </button>
            
            {/* Submenu */}
            {!collapsed && item.subItems && expandedMenus.includes(item.label) && (
              <div className="ml-4 mt-1 space-y-1 border-l border-sidebar-border pl-3">
                {item.subItems.map((subItem) => (
                  <Link
                    key={subItem.href}
                    href={subItem.href}
                    className={cn(
                      "flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
                      isActive(subItem.href)
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                    )}
                  >
                    <subItem.icon className="w-3.5 h-3.5" />
                    <span>{subItem.label}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      <div className="p-3 space-y-1 border-t border-sidebar-border">
        {bottomItems.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
              isActive(item.href)
                ? "bg-sidebar-accent text-sidebar-foreground"
                : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
            )}
          >
            <item.icon className="w-4 h-4 shrink-0" />
            {!collapsed && (
              <>
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <span className="px-1.5 py-0.5 text-xs rounded-full bg-destructive text-destructive-foreground">
                    {item.badge}
                  </span>
                )}
              </>
            )}
          </Link>
        ))}
      </div>

      <div className="p-3 border-t border-sidebar-border">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(!collapsed)}
          className="w-full"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </Button>
      </div>
    </aside>
  )
}
