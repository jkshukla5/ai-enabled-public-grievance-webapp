"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"
import { useLanguage } from "@/lib/language-context"

const data = [
  { time: "00:00", received: 45, classified: 42, resolved: 38 },
  { time: "02:00", received: 32, classified: 30, resolved: 28 },
  { time: "04:00", received: 28, classified: 26, resolved: 24 },
  { time: "06:00", received: 52, classified: 48, resolved: 42 },
  { time: "08:00", received: 89, classified: 85, resolved: 72 },
  { time: "10:00", received: 124, classified: 118, resolved: 98 },
  { time: "12:00", received: 98, classified: 94, resolved: 85 },
  { time: "14:00", received: 112, classified: 108, resolved: 92 },
  { time: "16:00", received: 95, classified: 92, resolved: 78 },
  { time: "18:00", received: 78, classified: 75, resolved: 68 },
  { time: "20:00", received: 62, classified: 60, resolved: 55 },
  { time: "22:00", received: 48, classified: 46, resolved: 42 },
]

export function GrievanceChart() {
  const { t } = useLanguage()
  
  return (
    <Card className="border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">{t("citizenComplaintsFlow")}</CardTitle>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-chart-1" />
              <span className="text-muted-foreground">Received</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-chart-2" />
              <span className="text-muted-foreground">Routed</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-success" />
              <span className="text-muted-foreground">Resolved</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorReceived" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.7 0.15 180)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.7 0.15 180)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorClassified" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.75 0.18 85)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.75 0.18 85)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.7 0.18 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.7 0.18 145)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.005 260)" vertical={false} />
              <XAxis
                dataKey="time"
                stroke="oklch(0.65 0 0)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="oklch(0.65 0 0)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${value}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.17 0.005 260)",
                  border: "1px solid oklch(0.25 0.005 260)",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                labelStyle={{ color: "oklch(0.95 0 0)" }}
              />
              <Area
                type="monotone"
                dataKey="received"
                stroke="oklch(0.7 0.15 180)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorReceived)"
              />
              <Area
                type="monotone"
                dataKey="classified"
                stroke="oklch(0.75 0.18 85)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorClassified)"
              />
              <Area
                type="monotone"
                dataKey="resolved"
                stroke="oklch(0.7 0.18 145)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorResolved)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
