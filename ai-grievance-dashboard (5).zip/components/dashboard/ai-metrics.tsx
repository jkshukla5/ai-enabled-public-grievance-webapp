"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, Zap, Target, Clock, Languages, Route } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

const metrics = [
  {
    icon: Target,
    label: "Classification Accuracy",
    value: "97.2%",
    description: "Dept. routing accuracy",
  },
  {
    icon: Zap,
    label: "Avg. Processing Time",
    value: "0.8s",
    description: "Per citizen complaint",
  },
  {
    icon: Languages,
    label: "Languages Supported",
    value: "12+",
    description: "Hindi, English, Regional",
  },
  {
    icon: Route,
    label: "Auto-Routing Rate",
    value: "89.5%",
    description: "Direct to department",
  },
]

export function AIMetrics() {
  const { t } = useLanguage()
  
  return (
    <Card className="border-border">
      <CardHeader className="pb-4">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary" />
          {t("aiMetrics")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {metrics.map((metric) => (
            <div
              key={metric.label}
              className="p-3 rounded-lg bg-secondary/50 border border-border"
            >
              <div className="flex items-center gap-2 mb-2">
                <metric.icon className="w-4 h-4 text-primary" />
                <span className="text-xs text-muted-foreground">
                  {metric.label}
                </span>
              </div>
              <p className="text-xl font-semibold text-foreground">
                {metric.value}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {metric.description}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
