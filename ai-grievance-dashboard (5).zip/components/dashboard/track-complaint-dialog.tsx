"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent } from "@/components/ui/card"
import {
  Search,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  Building2,
  User,
  Calendar,
  MapPin,
  Phone,
  Languages,
  ArrowRight,
  Loader2,
  XCircle,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ComplaintData {
  id: string
  complaint_id: string
  subject: string
  description: string
  status: string
  priority: string
  department: string
  category: string
  language: string
  ai_confidence: number
  created_at: string
  updated_at: string
  citizens: {
    name: string
    phone: string
    email?: string
    address: string
  }
  complaint_history?: Array<{
    status: string
    remarks: string
    updated_by: string
    created_at: string
  }>
}

export function TrackComplaintDialog() {
  const [open, setOpen] = useState(false)
  const [searchId, setSearchId] = useState("")
  const [complaint, setComplaint] = useState<ComplaintData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSearch = async () => {
    if (!searchId.trim()) {
      setError("Please enter a complaint ID")
      return
    }

    setLoading(true)
    setError("")
    setComplaint(null)

    try {
      const response = await fetch(
        `/api/complaints/track?id=${encodeURIComponent(searchId)}`
      )
      const data = await response.json()

      if (data.success) {
        setComplaint(data.data)
      } else {
        setError("Complaint not found. Please check the ID and try again.")
      }
    } catch (err) {
      console.error("[v0] Error tracking complaint:", err)
      setError("Error searching for complaint. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "resolved":
        return <CheckCircle className="w-5 h-5 text-success" />
      case "in-progress":
        return <Clock className="w-5 h-5 text-info" />
      case "pending":
        return <AlertCircle className="w-5 h-5 text-warning" />
      case "rejected":
        return <XCircle className="w-5 h-5 text-destructive" />
      default:
        return <FileText className="w-5 h-5 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-success/10 text-success border-success/20"
      case "in-progress":
        return "bg-info/10 text-info border-info/20"
      case "pending":
        return "bg-warning/10 text-warning border-warning/20"
      case "rejected":
        return "bg-destructive/10 text-destructive border-destructive/20"
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20"
    }
  }

  const getProgressValue = (status: string) => {
    switch (status) {
      case "pending":
        return 25
      case "in-progress":
        return 60
      case "resolved":
        return 100
      case "rejected":
        return 0
      default:
        return 0
    }
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const handleClose = () => {
    setOpen(false)
    setTimeout(() => {
      setSearchId("")
      setComplaint(null)
      setError("")
    }, 300)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Search className="w-4 h-4" />
          Track Complaint
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Track Your Complaint</DialogTitle>
          <DialogDescription>
            Enter your complaint ID to check the status
          </DialogDescription>
        </DialogHeader>

        {!complaint ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="complaint-id">Complaint ID</Label>
              <div className="flex gap-2">
                <Input
                  id="complaint-id"
                  placeholder="e.g., GRV-1234567890"
                  value={searchId}
                  onChange={(e) => setSearchId(e.target.value.toUpperCase())}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  disabled={loading}
                />
                <Button onClick={handleSearch} disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 mr-2" />
                      Search
                    </>
                  )}
                </Button>
              </div>
            </div>

            {error && (
              <div className="text-sm text-destructive p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                {error}
              </div>
            )}

            <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <p className="text-sm text-blue-900 dark:text-blue-100">
                You received a complaint ID when you registered your grievance. Please enter it above to track the status.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Complaint Header */}
            <Card className="border-border bg-muted/30">
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Complaint ID</p>
                      <p className="text-lg font-semibold">{complaint.complaint_id}</p>
                    </div>
                    <Badge
                      variant="outline"
                      className={cn("capitalize", getStatusColor(complaint.status))}
                    >
                      {getStatusIcon(complaint.status)}
                      <span className="ml-1">{complaint.status}</span>
                    </Badge>
                  </div>
                  <p className="text-sm font-medium">{complaint.subject}</p>
                </div>
              </CardContent>
            </Card>

            {/* Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Overall Progress</span>
                <span className="font-medium">{getProgressValue(complaint.status)}%</span>
              </div>
              <Progress
                value={getProgressValue(complaint.status)}
                className="h-2"
              />
            </div>

            {/* Complaint Details */}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">Department</p>
                <p className="font-medium">{complaint.department}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Priority</p>
                <Badge variant="outline" className="capitalize">
                  {complaint.priority}
                </Badge>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Language</p>
                <p className="font-medium">{complaint.language}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">AI Confidence</p>
                <Badge variant="secondary">{complaint.ai_confidence.toFixed(1)}%</Badge>
              </div>
            </div>

            {/* Citizen Info */}
            <Card className="border-border">
              <CardContent className="pt-4">
                <p className="text-xs font-medium text-muted-foreground mb-3">
                  Citizen Information
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span>{complaint.citizens.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span>{complaint.citizens.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span>{complaint.citizens.address}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            {complaint.complaint_history && complaint.complaint_history.length > 0 && (
              <Card className="border-border">
                <CardContent className="pt-4">
                  <p className="text-xs font-medium text-muted-foreground mb-3">
                    Status Timeline
                  </p>
                  <div className="space-y-2">
                    {complaint.complaint_history.map((history, index) => (
                      <div key={index} className="flex gap-3 text-sm">
                        <div className="flex flex-col items-center">
                          <div className={cn(
                            "w-2 h-2 rounded-full",
                            history.status === "resolved" ? "bg-success" : "bg-muted-foreground"
                          )} />
                          {index < complaint.complaint_history!.length - 1 && (
                            <div className="w-0.5 h-4 bg-border" />
                          )}
                        </div>
                        <div className="flex-1 pb-2">
                          <p className="font-medium capitalize">{history.status}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(history.created_at)}
                          </p>
                          {history.remarks && (
                            <p className="text-xs mt-1">{history.remarks}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Button onClick={() => {
              setComplaint(null)
              setSearchId("")
              setError("")
            }} variant="outline" className="w-full">
              Search Another Complaint
            </Button>
          </div>
        )}

        {complaint && (
          <DialogFooter>
            <Button onClick={handleClose} className="w-full">
              Close
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
}
