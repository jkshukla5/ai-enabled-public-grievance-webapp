'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Spinner } from '@/components/ui/spinner'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { AlertCircle, Zap, CheckCircle2, Clock } from 'lucide-react'
import { useComplaintClassification } from '@/hooks/use-ai-features'
import { useLanguage } from '@/lib/language-context'

interface ComplaintAnalysisProps {
  complaint: string
  language: string
}

export function ComplaintAnalysis({ complaint, language }: ComplaintAnalysisProps) {
  const { classify, isLoading, classification, error } = useComplaintClassification()
  const { t } = useLanguage()
  const [analyzed, setAnalyzed] = useState(false)

  const handleAnalyze = async () => {
    const result = await classify(complaint, language)
    if (result) {
      setAnalyzed(true)
    }
  }

  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" />
          AI-Powered Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!analyzed ? (
          <Button
            onClick={handleAnalyze}
            disabled={isLoading || !complaint}
            className="w-full"
            size="sm"
          >
            {isLoading ? (
              <>
                <Spinner className="w-4 h-4 mr-2" />
                Analyzing...
              </>
            ) : (
              'Analyze Complaint'
            )}
          </Button>
        ) : classification && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Department</p>
                <Badge className="bg-primary/20 text-primary">
                  {classification.department}
                </Badge>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Priority</p>
                <Badge
                  variant={
                    classification.priority === 'high'
                      ? 'destructive'
                      : classification.priority === 'medium'
                        ? 'default'
                        : 'secondary'
                  }
                >
                  {classification.priority}
                </Badge>
              </div>
            </div>

            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Category</p>
              <p className="text-sm text-foreground">{classification.category}</p>
            </div>

            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Summary</p>
              <p className="text-sm text-foreground">{classification.summary}</p>
            </div>

            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Suggested Action</p>
              <p className="text-sm text-foreground">
                {classification.suggestedAction}
              </p>
            </div>

            {classification.keywords && (
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">Keywords</p>
                <div className="flex flex-wrap gap-2">
                  {classification.keywords.map((keyword: string) => (
                    <Badge key={keyword} variant="outline" className="text-xs">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <Button
              onClick={() => setAnalyzed(false)}
              variant="outline"
              size="sm"
              className="w-full"
            >
              Re-analyze
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
