"use client"

import React, { createContext, useContext, useState, useEffect, useCallback } from "react"

export type Language = {
  code: string
  name: string
  nativeName: string
  region?: string
}

export const languages: Language[] = [
  { code: "en", name: "English", nativeName: "English", region: "IN" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी", region: "IN" },
  { code: "bn", name: "Bengali", nativeName: "বাংলা", region: "WB" },
  { code: "te", name: "Telugu", nativeName: "తెలుగు", region: "AP" },
  { code: "ta", name: "Tamil", nativeName: "தமிழ்", region: "TN" },
  { code: "mr", name: "Marathi", nativeName: "मराठी", region: "MH" },
  { code: "gu", name: "Gujarati", nativeName: "ગુજરાતી", region: "GJ" },
  { code: "kn", name: "Kannada", nativeName: "ಕನ್ನಡ", region: "KA" },
  { code: "ml", name: "Malayalam", nativeName: "മലയാളം", region: "KL" },
  { code: "pa", name: "Punjabi", nativeName: "ਪੰਜਾਬੀ", region: "PB" },
  { code: "or", name: "Odia", nativeName: "ଓଡ଼ିଆ", region: "OD" },
  { code: "as", name: "Assamese", nativeName: "অসমীয়া", region: "AS" },
]

// Translations for UI elements
export const translations: Record<string, Record<string, string>> = {
  en: {
    grievanceDashboard: "Grievance Dashboard",
    governmentPortal: "Government Portal",
    registerComplaint: "Register Complaint",
    trackComplaint: "Track Complaint",
    searchComplaints: "Search citizen complaints...",
    last12Hours: "Last 12 hours",
    myAccount: "My Account",
    profile: "Profile",
    settings: "Settings",
    logout: "Log out",
    admin: "Admin",
    language: "Language",
    autoDetect: "Auto-detect",
    locationBased: "Location Based",
    manual: "Manual Selection",
    totalComplaints: "Total Complaints",
    resolvedToday: "Resolved Today",
    awaitingAction: "Awaiting Action",
    urgentPriority: "Urgent Priority",
    citizenComplaintsFlow: "Citizen Complaints Flow",
    departmentClassification: "Department-wise Classification",
    recentComplaints: "Recent Citizen Complaints",
    aiMetrics: "AI Performance Metrics",
    activityFeed: "Recent Activity",
    overview: "Overview",
    allGrievances: "All Grievances",
    aiClassification: "AI Classification",
    analytics: "Analytics",
    departments: "Departments",
    officers: "Officers",
    notifications: "Notifications",
    help: "Help Center",
  },
  hi: {
    grievanceDashboard: "शिकायत डैशबोर्ड",
    governmentPortal: "सरकारी पोर्टल",
    registerComplaint: "शिकायत दर्ज करें",
    trackComplaint: "शिकायत ट्रैक करें",
    searchComplaints: "नागरिक शिकायतें खोजें...",
    last12Hours: "पिछले 12 घंटे",
    myAccount: "मेरा खाता",
    profile: "प्रोफाइल",
    settings: "सेटिंग्स",
    logout: "लॉग आउट",
    admin: "व्यवस्थापक",
    language: "भाषा",
    autoDetect: "स्वतः पहचान",
    locationBased: "स्थान आधारित",
    manual: "मैन्युअल चयन",
    totalComplaints: "कुल शिकायतें",
    resolvedToday: "आज हल हुईं",
    awaitingAction: "कार्रवाई प्रतीक्षित",
    urgentPriority: "अति आवश्यक",
    citizenComplaintsFlow: "नागरिक शिकायत प्रवाह",
    departmentClassification: "विभाग-वार वर्गीकरण",
    recentComplaints: "हाल की नागरिक शिकायतें",
    aiMetrics: "AI प्रदर्शन मेट्रिक्स",
    activityFeed: "हाल की गतिविधि",
    overview: "अवलोकन",
    allGrievances: "सभी शिकायतें",
    aiClassification: "AI वर्गीकरण",
    analytics: "विश्लेषिकी",
    departments: "विभाग",
    officers: "अधिकारी",
    notifications: "सूचनाएं",
    help: "सहायता केंद्र",
  },
  bn: {
    grievanceDashboard: "অভিযোগ ড্যাশবোর্ড",
    governmentPortal: "সরকারি পোর্টাল",
    registerComplaint: "অভিযোগ দায়ের করুন",
    trackComplaint: "অভিযোগ ট্র্যাক করুন",
    searchComplaints: "নাগরিক অভিযোগ খুঁজুন...",
    last12Hours: "গত ১২ ঘন্টা",
    myAccount: "আমার অ্যাকাউন্ট",
    profile: "প্রোফাইল",
    settings: "সেটিংস",
    logout: "লগ আউট",
    admin: "প্রশাসক",
    language: "ভাষা",
    autoDetect: "স্বয়ংক্রিয় সনাক্ত",
    locationBased: "অবস্থান ভিত্তিক",
    manual: "ম্যানুয়াল নির্বাচন",
    totalComplaints: "মোট অভিযোগ",
    resolvedToday: "আজ সমাধান হয়েছে",
    awaitingAction: "পদক্ষেপের অপেক্ষায়",
    urgentPriority: "জরুরি অগ্রাধিকার",
    citizenComplaintsFlow: "নাগরিক অভিযোগ প্রবাহ",
    departmentClassification: "বিভাগ-ভিত্তিক শ্রেণীবিভাগ",
    recentComplaints: "সাম্প্রতিক নাগরিক অভিযোগ",
    aiMetrics: "AI কর্মক্ষমতা মেট্রিক্স",
    activityFeed: "সাম্প্রতিক কার্যকলাপ",
    overview: "সংক্ষিপ্ত বিবরণ",
    allGrievances: "সমস্ত অভিযোগ",
    aiClassification: "AI শ্রেণীবিভাগ",
    analytics: "বিশ্লেষণ",
    departments: "বিভাগসমূহ",
    officers: "কর্মকর্তারা",
    notifications: "বিজ্ঞপ্তি",
    help: "সহায়তা কেন্দ্র",
  },
  te: {
    grievanceDashboard: "ఫిర్యాదు డాష్‌బోర్డ్",
    governmentPortal: "ప్రభుత్వ పోర్టల్",
    registerComplaint: "ఫిర్యాదు నమోదు చేయండి",
    trackComplaint: "ఫిర్యాదు ట్రాక్ చేయండి",
    searchComplaints: "పౌర ఫిర్యాదులను శోధించండి...",
    last12Hours: "గత 12 గంటలు",
    myAccount: "నా ఖాతా",
    profile: "ప్రొఫైల్",
    settings: "సెట్టింగ్‌లు",
    logout: "లాగ్ అవుట్",
    admin: "నిర్వాహకుడు",
    language: "భాష",
    autoDetect: "ఆటో-డిటెక్ట్",
    locationBased: "స్థానం ఆధారంగా",
    manual: "మాన్యువల్ ఎంపిక",
    totalComplaints: "మొత్తం ఫిర్యాదులు",
    resolvedToday: "ఈరోజు పరిష్కరించబడినవి",
    awaitingAction: "చర్య కోసం వేచి ఉన్నవి",
    urgentPriority: "అత్యవసర ప్రాధాన్యత",
    citizenComplaintsFlow: "పౌర ఫిర్యాదుల ప్రవాహం",
    departmentClassification: "విభాగం వారీగా వర్గీకరణ",
    recentComplaints: "ఇటీవలి పౌర ఫిర్యాదులు",
    aiMetrics: "AI పనితీరు మెట్రిక్స్",
    activityFeed: "ఇటీవలి కార్యకలాపాలు",
    overview: "అవలోకనం",
    allGrievances: "అన్ని ఫిర్యాదులు",
    aiClassification: "AI వర్గీకరణ",
    analytics: "విశ్లేషణలు",
    departments: "విభాగాలు",
    officers: "అధికారులు",
    notifications: "నోటిఫికేషన్లు",
    help: "సహాయ కేంద్రం",
  },
  ta: {
    grievanceDashboard: "புகார் டாஷ்போர்டு",
    governmentPortal: "அரசு போர்டல்",
    registerComplaint: "புகார் பதிவு செய்",
    trackComplaint: "புகார் கண்காணி",
    searchComplaints: "குடிமக்கள் புகார்களைத் தேடுங்கள்...",
    last12Hours: "கடந்த 12 மணி நேரம்",
    myAccount: "என் கணக்கு",
    profile: "சுயவிவரம்",
    settings: "அமைப்புகள்",
    logout: "வெளியேறு",
    admin: "நிர்வாகி",
    language: "மொழி",
    autoDetect: "தானாக கண்டறி",
    locationBased: "இருப்பிட அடிப்படையில்",
    manual: "கைமுறை தேர்வு",
    totalComplaints: "மொத்த புகார்கள்",
    resolvedToday: "இன்று தீர்க்கப்பட்டது",
    awaitingAction: "நடவடிக்கைக்காக காத்திருக்கிறது",
    urgentPriority: "அவசர முன்னுரிமை",
    citizenComplaintsFlow: "குடிமக்கள் புகார் ஓட்டம்",
    departmentClassification: "துறை வாரியான வகைப்பாடு",
    recentComplaints: "சமீபத்திய குடிமக்கள் புகார்கள்",
    aiMetrics: "AI செயல்திறன் அளவீடுகள்",
    activityFeed: "சமீபத்திய செயல்பாடு",
    overview: "மேலோட்டம்",
    allGrievances: "அனைத்து புகார்கள்",
    aiClassification: "AI வகைப்பாடு",
    analytics: "பகுப்பாய்வு",
    departments: "துறைகள்",
    officers: "அதிகாரிகள்",
    notifications: "அறிவிப்புகள்",
    help: "உதவி மையம்",
  },
  mr: {
    grievanceDashboard: "तक्रार डॅशबोर्ड",
    governmentPortal: "सरकारी पोर्टल",
    registerComplaint: "तक्रार नोंदवा",
    trackComplaint: "तक्रार ट्रॅक करा",
    searchComplaints: "नागरिक तक्रारी शोधा...",
    last12Hours: "मागील 12 तास",
    myAccount: "माझे खाते",
    profile: "प्रोफाइल",
    settings: "सेटिंग्ज",
    logout: "लॉग आउट",
    admin: "प्रशासक",
    language: "भाषा",
    autoDetect: "ऑटो-डिटेक्ट",
    locationBased: "स्थान आधारित",
    manual: "मॅन्युअल निवड",
    totalComplaints: "एकूण तक्रारी",
    resolvedToday: "आज निराकरण झाले",
    awaitingAction: "कार्यवाही प्रलंबित",
    urgentPriority: "तातडीचे प्राधान्य",
    citizenComplaintsFlow: "नागरिक तक्रार प्रवाह",
    departmentClassification: "विभागनिहाय वर्गीकरण",
    recentComplaints: "अलीकडील नागरिक तक्रारी",
    aiMetrics: "AI कार्यप्रदर्शन मेट्रिक्स",
    activityFeed: "अलीकडील क्रियाकलाप",
    overview: "आढावा",
    allGrievances: "सर्व तक्रारी",
    aiClassification: "AI वर्गीकरण",
    analytics: "विश्लेषण",
    departments: "विभाग",
    officers: "अधिकारी",
    notifications: "सूचना",
    help: "मदत केंद्र",
  },
  gu: {
    grievanceDashboard: "ફરિયાદ ડેશબોર્ડ",
    governmentPortal: "સરકારી પોર્ટલ",
    registerComplaint: "ફરિયાદ નોંધાવો",
    trackComplaint: "ફરિયાદ ટ્રેક કરો",
    searchComplaints: "નાગરિક ફરિયાદો શોધો...",
    last12Hours: "છેલ્લા 12 કલાક",
    myAccount: "મારું ખાતું",
    profile: "પ્રોફાઇલ",
    settings: "સેટિંગ્સ",
    logout: "લૉગ આઉટ",
    admin: "એડમિન",
    language: "ભાષા",
    autoDetect: "ઓટો-ડિટેક્ટ",
    locationBased: "સ્થાન આધારિત",
    manual: "મેન્યુઅલ પસંદગી",
    totalComplaints: "કુલ ફરિયાદો",
    resolvedToday: "આજે ઉકેલાયેલ",
    awaitingAction: "કાર્યવાહીની રાહ",
    urgentPriority: "તાત્કાલિક પ્રાથમિકતા",
    citizenComplaintsFlow: "નાગરિક ફરિયાદ પ્રવાહ",
    departmentClassification: "વિભાગ મુજબ વર્ગીકરણ",
    recentComplaints: "તાજેતરની નાગરિક ફરિયાદો",
    aiMetrics: "AI પ્રદર્શન મેટ્રિક્સ",
    activityFeed: "તાજેતરની પ્રવૃત્તિ",
    overview: "ઝાંખી",
    allGrievances: "બધી ફરિયાદો",
    aiClassification: "AI વર્ગીકરણ",
    analytics: "વિશ્લેષણ",
    departments: "વિભાગો",
    officers: "અધિકારીઓ",
    notifications: "સૂચનાઓ",
    help: "મદદ કેન્દ્ર",
  },
  kn: {
    grievanceDashboard: "ದೂರು ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    governmentPortal: "ಸರ್ಕಾರಿ ಪೋರ್ಟಲ್",
    registerComplaint: "ದೂರು ನೋಂದಣಿ",
    trackComplaint: "ದೂರು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ",
    searchComplaints: "ನಾಗರಿಕ ದೂರುಗಳನ್ನು ಹುಡುಕಿ...",
    last12Hours: "ಕಳೆದ 12 ಗಂಟೆಗಳು",
    myAccount: "ನನ್ನ ಖಾತೆ",
    profile: "ಪ್ರೊಫೈಲ್",
    settings: "ಸೆಟ್ಟಿಂಗ್‌ಗಳು",
    logout: "ಲಾಗ್ ಔಟ್",
    admin: "ನಿರ್ವಾಹಕ",
    language: "ಭಾಷೆ",
    autoDetect: "ಸ್ವಯಂ-ಪತ್ತೆ",
    locationBased: "ಸ್ಥಳ ಆಧಾರಿತ",
    manual: "ಹಸ್ತಚಾಲಿತ ಆಯ್ಕೆ",
    totalComplaints: "ಒಟ್ಟು ದೂರುಗಳು",
    resolvedToday: "ಇಂದು ಪರಿಹರಿಸಲಾಗಿದೆ",
    awaitingAction: "ಕ್ರಮಕ್ಕಾಗಿ ಕಾಯುತ್ತಿದೆ",
    urgentPriority: "ತುರ್ತು ಆದ್ಯತೆ",
    citizenComplaintsFlow: "ನಾಗರಿಕ ದೂರು ಹರಿವು",
    departmentClassification: "ಇಲಾಖೆವಾರು ವರ್ಗೀಕರಣ",
    recentComplaints: "ಇತ್ತೀಚಿನ ನಾಗರಿಕ ದೂರುಗಳು",
    aiMetrics: "AI ಕಾರ್ಯಕ್ಷಮತೆ ಮೆಟ್ರಿಕ್ಸ್",
    activityFeed: "ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ",
    overview: "ಅವಲೋಕನ",
    allGrievances: "ಎಲ್ಲಾ ದೂರುಗಳು",
    aiClassification: "AI ವರ್ಗೀಕರಣ",
    analytics: "ವಿಶ್ಲೇಷಣೆ",
    departments: "ಇಲಾಖೆಗಳು",
    officers: "ಅಧಿಕಾರಿಗಳು",
    notifications: "ಅಧಿಸೂಚನೆಗಳು",
    help: "ಸಹಾಯ ಕೇಂದ್ರ",
  },
  ml: {
    grievanceDashboard: "പരാതി ഡാഷ്‌ബോർഡ്",
    governmentPortal: "സർക്കാർ പോർട്ടൽ",
    registerComplaint: "പരാതി രജിസ്റ്റർ ചെയ്യുക",
    trackComplaint: "പരാതി ട്രാക്ക് ചെയ്യുക",
    searchComplaints: "പൗര പരാതികൾ തിരയുക...",
    last12Hours: "കഴിഞ്ഞ 12 മണിക്കൂർ",
    myAccount: "എന്റെ അക്കൗണ്ട്",
    profile: "പ്രൊഫൈൽ",
    settings: "ക്രമീകരണങ്ങൾ",
    logout: "ലോഗ് ഔട്ട്",
    admin: "അഡ്മിൻ",
    language: "ഭാഷ",
    autoDetect: "ഓട്ടോ-ഡിറ്റക്റ്റ്",
    locationBased: "സ്ഥാന അടിസ്ഥാനം",
    manual: "മാനുവൽ തിരഞ്ഞെടുപ്പ്",
    totalComplaints: "ആകെ പരാതികൾ",
    resolvedToday: "ഇന്ന് പരിഹരിച്ചു",
    awaitingAction: "നടപടിക്കായി കാത്തിരിക്കുന്നു",
    urgentPriority: "അടിയന്തര മുൻഗണന",
    citizenComplaintsFlow: "പൗര പരാതി ഫ്ലോ",
    departmentClassification: "വകുപ്പ് തിരിച്ചുള്ള വർഗ്ഗീകരണം",
    recentComplaints: "സമീപകാല പൗര പരാതികൾ",
    aiMetrics: "AI പ്രകടന മെട്രിക്സ്",
    activityFeed: "സമീപകാല പ്രവർത്തനം",
    overview: "അവലോകനം",
    allGrievances: "എല്ലാ പരാതികളും",
    aiClassification: "AI വർഗ്ഗീകരണം",
    analytics: "അനലിറ്റിക്സ്",
    departments: "വകുപ്പുകൾ",
    officers: "ഉദ്യോഗസ്ഥർ",
    notifications: "അറിയിപ്പുകൾ",
    help: "സഹായ കേന്ദ്രം",
  },
  pa: {
    grievanceDashboard: "ਸ਼ਿਕਾਇਤ ਡੈਸ਼ਬੋਰਡ",
    governmentPortal: "ਸਰਕਾਰੀ ਪੋਰਟਲ",
    registerComplaint: "ਸ਼ਿਕਾਇਤ ਦਰਜ ਕਰੋ",
    trackComplaint: "ਸ਼ਿਕਾਇਤ ਟ੍ਰੈਕ ਕਰੋ",
    searchComplaints: "ਨਾਗਰਿਕ ਸ਼ਿਕਾਇਤਾਂ ਖੋਜੋ...",
    last12Hours: "ਪਿਛਲੇ 12 ਘੰਟੇ",
    myAccount: "ਮੇਰਾ ਖਾਤਾ",
    profile: "ਪ੍ਰੋਫਾਈਲ",
    settings: "ਸੈਟਿੰਗਾਂ",
    logout: "ਲੌਗ ਆਊਟ",
    admin: "ਪ੍ਰਬੰਧਕ",
    language: "ਭਾਸ਼ਾ",
    autoDetect: "ਆਟੋ-ਡਿਟੈਕਟ",
    locationBased: "ਸਥਾਨ ਅਧਾਰਿਤ",
    manual: "ਮੈਨੂਅਲ ਚੋਣ",
    totalComplaints: "ਕੁੱਲ ਸ਼ਿਕਾਇਤਾਂ",
    resolvedToday: "ਅੱਜ ਹੱਲ ਹੋਈਆਂ",
    awaitingAction: "ਕਾਰਵਾਈ ਦੀ ਉਡੀਕ",
    urgentPriority: "ਜ਼ਰੂਰੀ ਤਰਜੀਹ",
    citizenComplaintsFlow: "ਨਾਗਰਿਕ ਸ਼ਿਕਾਇਤ ਪ੍ਰਵਾਹ",
    departmentClassification: "ਵਿਭਾਗ ਅਨੁਸਾਰ ਵਰਗੀਕਰਨ",
    recentComplaints: "ਹਾਲੀਆ ਨਾਗਰਿਕ ਸ਼ਿਕਾਇਤਾਂ",
    aiMetrics: "AI ਪ੍ਰਦਰਸ਼ਨ ਮੈਟ੍ਰਿਕਸ",
    activityFeed: "ਹਾਲੀਆ ਗਤੀਵਿਧੀ",
    overview: "ਸੰਖੇਪ",
    allGrievances: "ਸਾਰੀਆਂ ਸ਼ਿਕਾਇਤਾਂ",
    aiClassification: "AI ਵਰਗੀਕਰਨ",
    analytics: "ਵਿਸ਼ਲੇਸ਼ਣ",
    departments: "ਵਿਭਾਗ",
    officers: "ਅਧਿਕਾਰੀ",
    notifications: "ਸੂਚਨਾਵਾਂ",
    help: "ਮਦਦ ਕੇਂਦਰ",
  },
  or: {
    grievanceDashboard: "ଅଭିଯୋଗ ଡ୍ୟାସବୋର୍ଡ",
    governmentPortal: "ସରକାରୀ ପୋର୍ଟାଲ",
    registerComplaint: "ଅଭିଯୋଗ ପଞ୍ଜୀକରଣ",
    trackComplaint: "ଅଭିଯୋଗ ଟ୍ରାକ୍ କରନ୍ତୁ",
    searchComplaints: "ନାଗରିକ ଅଭିଯୋଗ ଖୋଜନ୍ତୁ...",
    last12Hours: "ଗତ 12 ଘଣ୍ଟା",
    myAccount: "ମୋ ଖାତା",
    profile: "ପ୍ରୋଫାଇଲ୍",
    settings: "ସେଟିଂସ୍",
    logout: "ଲଗ୍ ଆଉଟ୍",
    admin: "ଆଡମିନ୍",
    language: "ଭାଷା",
    autoDetect: "ଅଟୋ-ଡିଟେକ୍ଟ",
    locationBased: "ଅବସ୍ଥାନ ଆଧାରିତ",
    manual: "ମାନୁଆଲ ଚୟନ",
    totalComplaints: "ମୋଟ ଅଭିଯୋଗ",
    resolvedToday: "ଆଜି ସମାଧାନ ହୋଇଛି",
    awaitingAction: "କାର୍ଯ୍ୟ ପାଇଁ ଅପେକ୍ଷା",
    urgentPriority: "ଜରୁରୀ ପ୍ରାଥମିକତା",
    citizenComplaintsFlow: "ନାଗରିକ ଅଭିଯୋଗ ପ୍ରବାହ",
    departmentClassification: "ବିଭାଗ ଅନୁଯାୟୀ ଶ୍ରେଣୀକରଣ",
    recentComplaints: "ସାମ୍ପ୍ରତିକ ନାଗରିକ ଅଭିଯୋଗ",
    aiMetrics: "AI ପ୍ରଦର୍ଶନ ମେଟ୍ରିକ୍ସ",
    activityFeed: "ସାମ୍ପ୍ରତିକ କାର୍ଯ୍ୟକଳାପ",
    overview: "ସାରାଂଶ",
    allGrievances: "ସମସ୍ତ ଅଭିଯୋଗ",
    aiClassification: "AI ଶ୍ରେଣୀକରଣ",
    analytics: "ବିଶ୍ଳେଷଣ",
    departments: "ବିଭାଗଗୁଡ଼ିକ",
    officers: "ଅଧିକାରୀମାନେ",
    notifications: "ବିଜ୍ଞପ୍ତି",
    help: "ସହାୟତା କେନ୍ଦ୍ର",
  },
  as: {
    grievanceDashboard: "অভিযোগ ডেশ্বব'ৰ্ড",
    governmentPortal: "চৰকাৰী প'ৰ্টেল",
    registerComplaint: "অভিযোগ পঞ্জীয়ন",
    trackComplaint: "অভিযোগ ট্ৰেক কৰক",
    searchComplaints: "নাগৰিক অভিযোগ সন্ধান কৰক...",
    last12Hours: "যোৱা ১২ ঘণ্টা",
    myAccount: "মোৰ একাউণ্ট",
    profile: "প্ৰ'ফাইল",
    settings: "ছেটিংছ",
    logout: "লগ আউট",
    admin: "প্ৰশাসক",
    language: "ভাষা",
    autoDetect: "স্বয়ংক্ৰিয় চিনাক্ত",
    locationBased: "স্থান ভিত্তিক",
    manual: "মেনুৱেল নিৰ্বাচন",
    totalComplaints: "মুঠ অভিযোগ",
    resolvedToday: "আজি সমাধান হৈছে",
    awaitingAction: "পদক্ষেপৰ অপেক্ষাত",
    urgentPriority: "জৰুৰী অগ্ৰাধিকাৰ",
    citizenComplaintsFlow: "নাগৰিক অভিযোগ প্ৰবাহ",
    departmentClassification: "বিভাগ অনুসৰি শ্ৰেণীবিভাগ",
    recentComplaints: "শেহতীয়া নাগৰিক অভিযোগ",
    aiMetrics: "AI কাৰ্যক্ষমতা মেট্ৰিক্স",
    activityFeed: "শেহতীয়া কাৰ্যকলাপ",
    overview: "সাৰাংশ",
    allGrievances: "সকলো অভিযোগ",
    aiClassification: "AI শ্ৰেণীবিভাগ",
    analytics: "বিশ্লেষণ",
    departments: "বিভাগসমূহ",
    officers: "বিষয়াসকল",
    notifications: "জাননী",
    help: "সহায় কেন্দ্ৰ",
  },
}

type LanguageContextType = {
  currentLanguage: Language
  setLanguage: (lang: Language) => void
  isAutoDetect: boolean
  setAutoDetect: (auto: boolean) => void
  t: (key: string) => string
  detectLocationLanguage: () => Promise<void>
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

// State-to-language mapping for India
const stateLanguageMap: Record<string, string> = {
  "Andhra Pradesh": "te",
  "Telangana": "te",
  "Tamil Nadu": "ta",
  "Karnataka": "kn",
  "Kerala": "ml",
  "Maharashtra": "mr",
  "Gujarat": "gu",
  "West Bengal": "bn",
  "Punjab": "pa",
  "Odisha": "or",
  "Assam": "as",
  "Delhi": "hi",
  "Uttar Pradesh": "hi",
  "Madhya Pradesh": "hi",
  "Bihar": "hi",
  "Rajasthan": "hi",
  "Jharkhand": "hi",
  "Chhattisgarh": "hi",
  "Haryana": "hi",
  "Uttarakhand": "hi",
  "Himachal Pradesh": "hi",
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(languages[0])
  const [isAutoDetect, setAutoDetect] = useState(true)
  const [isInitialized, setIsInitialized] = useState(false)

  const detectLocationLanguage = useCallback(async () => {
    try {
      // First try browser language
      const browserLang = navigator.language.split("-")[0]
      const matchedLang = languages.find(l => l.code === browserLang)
      
      if (matchedLang) {
        setCurrentLanguage(matchedLang)
        localStorage.setItem("preferredLanguage", matchedLang.code)
        return
      }

      // Try geolocation-based detection using IP
      const response = await fetch("https://ipapi.co/json/")
      if (response.ok) {
        const data = await response.json()
        const region = data.region
        
        if (region && stateLanguageMap[region]) {
          const langCode = stateLanguageMap[region]
          const detectedLang = languages.find(l => l.code === langCode)
          if (detectedLang) {
            setCurrentLanguage(detectedLang)
            localStorage.setItem("preferredLanguage", detectedLang.code)
            return
          }
        }
      }
    } catch {
      // Fallback to English if detection fails
      console.log("Language detection failed, using English")
    }
  }, [])

  useEffect(() => {
    // Load saved preference
    const savedLang = localStorage.getItem("preferredLanguage")
    const savedAutoDetect = localStorage.getItem("autoDetectLanguage")
    
    if (savedAutoDetect !== null) {
      setAutoDetect(savedAutoDetect === "true")
    }

    if (savedLang && !isAutoDetect) {
      const lang = languages.find(l => l.code === savedLang)
      if (lang) {
        setCurrentLanguage(lang)
      }
    } else if (isAutoDetect && !isInitialized) {
      detectLocationLanguage()
    }
    
    setIsInitialized(true)
  }, [isAutoDetect, isInitialized, detectLocationLanguage])

  const setLanguage = (lang: Language) => {
    setCurrentLanguage(lang)
    setAutoDetect(false)
    localStorage.setItem("preferredLanguage", lang.code)
    localStorage.setItem("autoDetectLanguage", "false")
  }

  const handleSetAutoDetect = (auto: boolean) => {
    setAutoDetect(auto)
    localStorage.setItem("autoDetectLanguage", String(auto))
    if (auto) {
      detectLocationLanguage()
    }
  }

  const t = (key: string): string => {
    const langTranslations = translations[currentLanguage.code] || translations.en
    return langTranslations[key] || translations.en[key] || key
  }

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        setLanguage,
        isAutoDetect,
        setAutoDetect: handleSetAutoDetect,
        t,
        detectLocationLanguage,
      }}
    >
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
