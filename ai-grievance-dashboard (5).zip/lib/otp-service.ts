// OTP Service for verifying phone numbers

interface OTPSession {
  phone: string
  otp: string
  generatedAt: number
  attempts: number
  verified: boolean
}

// In-memory storage for OTP sessions (in production, use a database)
const otpSessions = new Map<string, OTPSession>()

// OTP validity period in milliseconds (5 minutes)
const OTP_VALIDITY = 5 * 60 * 1000

// Maximum OTP verification attempts
const MAX_ATTEMPTS = 3

// Generate a 6-digit OTP
export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// Send OTP to phone number (simulated - in production use SMS API like Twilio)
export async function sendOTP(phone: string): Promise<{ success: boolean; otp?: string }> {
  try {
    const otp = generateOTP()
    
    // Store OTP session
    otpSessions.set(phone, {
      phone,
      otp,
      generatedAt: Date.now(),
      attempts: 0,
      verified: false,
    })

    // In production, send via SMS API
    console.log(`[OTP Service] Sending OTP ${otp} to ${phone}`)
    
    // For demo purposes, log the OTP to console
    // In a real app, this would be sent via SMS
    console.log(`[Demo] OTP for ${phone}: ${otp}`)

    return { success: true, otp } // In production, don't return OTP
  } catch (error) {
    console.error("[OTP Service] Error sending OTP:", error)
    return { success: false }
  }
}

// Verify OTP
export function verifyOTP(phone: string, otp: string): { success: boolean; message: string } {
  const session = otpSessions.get(phone)

  if (!session) {
    return { success: false, message: "No OTP request found. Please request a new OTP." }
  }

  // Check if OTP has expired
  if (Date.now() - session.generatedAt > OTP_VALIDITY) {
    otpSessions.delete(phone)
    return { success: false, message: "OTP has expired. Please request a new OTP." }
  }

  // Check if maximum attempts exceeded
  if (session.attempts >= MAX_ATTEMPTS) {
    otpSessions.delete(phone)
    return { success: false, message: "Maximum attempts exceeded. Please request a new OTP." }
  }

  // Verify OTP
  if (session.otp === otp) {
    session.verified = true
    return { success: true, message: "Phone number verified successfully!" }
  }

  // Increment attempt count
  session.attempts += 1
  const remainingAttempts = MAX_ATTEMPTS - session.attempts

  if (remainingAttempts === 0) {
    otpSessions.delete(phone)
    return { success: false, message: "Maximum attempts exceeded. Please request a new OTP." }
  }

  return { 
    success: false, 
    message: `Invalid OTP. You have ${remainingAttempts} attempt${remainingAttempts > 1 ? 's' : ''} remaining.` 
  }
}

// Check if phone is verified
export function isPhoneVerified(phone: string): boolean {
  const session = otpSessions.get(phone)
  return session ? session.verified : false
}

// Resend OTP
export async function resendOTP(phone: string): Promise<{ success: boolean; message: string }> {
  const session = otpSessions.get(phone)

  if (!session) {
    return { success: false, message: "No previous OTP request found." }
  }

  // Check if enough time has passed since last request (30 seconds)
  const timeSinceLastOTP = Date.now() - session.generatedAt
  if (timeSinceLastOTP < 30000) {
    const waitTime = Math.ceil((30000 - timeSinceLastOTP) / 1000)
    return { success: false, message: `Please wait ${waitTime} seconds before requesting a new OTP.` }
  }

  // Generate new OTP
  const newOTP = generateOTP()
  session.otp = newOTP
  session.generatedAt = Date.now()
  session.attempts = 0
  session.verified = false

  console.log(`[OTP Service] Resending OTP ${newOTP} to ${phone}`)
  console.log(`[Demo] OTP for ${phone}: ${newOTP}`)

  return { success: true, message: "New OTP sent to your phone number." }
}

// Clear OTP session (after successful complaint submission)
export function clearOTPSession(phone: string): void {
  otpSessions.delete(phone)
}
