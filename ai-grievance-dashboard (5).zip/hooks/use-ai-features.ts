import { useCallback, useState } from 'react'

export function useComplaintClassification() {
  const [isLoading, setIsLoading] = useState(false)
  const [classification, setClassification] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const classify = useCallback(async (complaint: string, language: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/ai/classify-complaint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ complaint, language }),
      })

      if (!response.ok) throw new Error('Classification failed')

      const reader = response.body?.getReader()
      let result = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          result += new TextDecoder().decode(value)
        }
      }

      try {
        const parsed = JSON.parse(result)
        setClassification(parsed)
        return parsed
      } catch {
        setError('Failed to parse classification')
        return null
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Classification error')
      return null
    } finally {
      setIsLoading(false)
    }
  }, [])

  return { classify, isLoading, classification, error }
}

export function useTranslation() {
  const [isLoading, setIsLoading] = useState(false)
  const [translation, setTranslation] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const translate = useCallback(async (text: string, targetLanguage: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, targetLanguage }),
      })

      if (!response.ok) throw new Error('Translation failed')

      const reader = response.body?.getReader()
      let result = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          result += new TextDecoder().decode(value)
        }
      }

      setTranslation(result)
      return result
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Translation error')
      return null
    } finally {
      setIsLoading(false)
    }
  }, [])

  return { translate, isLoading, translation, error }
}

export function useActionPlanGeneration() {
  const [isLoading, setIsLoading] = useState(false)
  const [actionPlan, setActionPlan] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const generatePlan = useCallback(async (complaint: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/ai/action-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ complaint }),
      })

      if (!response.ok) throw new Error('Plan generation failed')

      const reader = response.body?.getReader()
      let result = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          result += new TextDecoder().decode(value)
        }
      }

      try {
        const parsed = JSON.parse(result)
        setActionPlan(parsed)
        return parsed
      } catch {
        setError('Failed to parse action plan')
        return null
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Generation error')
      return null
    } finally {
      setIsLoading(false)
    }
  }, [])

  return { generatePlan, isLoading, actionPlan, error }
}

export function useResponseGeneration() {
  const [isLoading, setIsLoading] = useState(false)
  const [response, setResponse] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const generateResponse = useCallback(async (complaint: string, department: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const fetchResponse = await fetch('/api/ai/generate-response', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ complaint, department }),
      })

      if (!fetchResponse.ok) throw new Error('Response generation failed')

      const reader = fetchResponse.body?.getReader()
      let result = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          result += new TextDecoder().decode(value)
        }
      }

      setResponse(result)
      return result
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Generation error')
      return null
    } finally {
      setIsLoading(false)
    }
  }, [])

  return { generateResponse, isLoading, response, error }
}
