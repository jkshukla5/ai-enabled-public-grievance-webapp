import { useState, useEffect } from 'react'

interface DashboardStats {
  totalComplaints: number
  resolved: number
  pending: number
  urgent: number
  todayComplaints: number
  departmentStats: Record<string, number>
}

export function useDashboardData() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchStats = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/dashboard/stats')
      const data = await response.json()

      if (data.success) {
        setStats(data.stats)
        setError(null)
      } else {
        setError('Failed to fetch statistics')
      }
    } catch (err) {
      console.error('[v0] Error fetching dashboard data:', err)
      setError('Error loading dashboard data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStats()
    const interval = setInterval(fetchStats, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  return { stats, loading, error, refetch: fetchStats }
}

interface Complaint {
  id: string
  complaint_id: string
  subject: string
  description: string
  department: string
  category: string
  priority: string
  status: string
  language: string
  ai_confidence: number
  created_at: string
  citizens: {
    name: string
    phone: string
    email?: string
  }
}

export function useComplaints(
  status?: string,
  department?: string,
  limit: number = 50
) {
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchComplaints = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (status) params.append('status', status)
      if (department) params.append('department', department)
      params.append('limit', limit.toString())

      const response = await fetch(`/api/complaints/list?${params}`)
      const data = await response.json()

      if (data.success) {
        setComplaints(data.data)
        setError(null)
      } else {
        setError('Failed to fetch complaints')
      }
    } catch (err) {
      console.error('[v0] Error fetching complaints:', err)
      setError('Error loading complaints')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchComplaints()
  }, [status, department, limit])

  return { complaints, loading, error, refetch: fetchComplaints }
}
