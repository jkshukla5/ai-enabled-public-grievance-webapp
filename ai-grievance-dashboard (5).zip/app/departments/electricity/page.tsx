import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Zap, TrendingUp, Clock, CheckCircle, AlertTriangle, User, MapPin } from "lucide-react"

const stats = {
  total: 3456,
  resolved: 3012,
  pending: 312,
  urgent: 45,
  avgTime: "1.2 days",
  satisfaction: 4.3,
}

const recentComplaints = [
  { id: "GRV-1267", subject: "Power outage in Sector 15 - Hospital affected", priority: "high", status: "in-progress", citizen: "Ramesh Kumar", location: "Sector 15, Block A", time: "2 hours ago" },
  { id: "GRV-1265", subject: "Street lights not working near school", priority: "medium", status: "pending", citizen: "Priya Singh", location: "Civil Lines", time: "4 hours ago" },
  { id: "GRV-1263", subject: "Transformer making loud noise", priority: "high", status: "in-progress", citizen: "Mohammad Ali", location: "Gandhi Nagar", time: "5 hours ago" },
  { id: "GRV-1261", subject: "Electricity meter showing wrong reading", priority: "low", status: "pending", citizen: "Sunita Devi", location: "Rajpur Road", time: "8 hours ago" },
  { id: "GRV-1259", subject: "Frequent power cuts in industrial area", priority: "high", status: "resolved", citizen: "Industrial Association", location: "SIDCO Industrial Estate", time: "12 hours ago" },
]

const issueTypes = [
  { type: "Power Outages", count: 456, percentage: 35 },
  { type: "Street Lights", count: 312, percentage: 24 },
  { type: "Meter Issues", count: 234, percentage: 18 },
  { type: "Billing Errors", count: 189, percentage: 15 },
  { type: "New Connection", count: 98, percentage: 8 },
]

const assignedOfficers = [
  { name: "AE Sharma", zone: "Zone 1", pending: 12, resolved: 45 },
  { name: "JE Verma", zone: "Zone 2", pending: 8, resolved: 38 },
  { name: "AE Singh", zone: "Zone 3", pending: 15, resolved: 52 },
  { name: "JE Patel", zone: "Zone 4", pending: 6, resolved: 41 },
]

export default function ElectricityDepartmentPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
              <Zap className="w-6 h-6 text-warning" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Electricity Department</h1>
              <p className="text-muted-foreground">Power supply and electrical infrastructure complaints</p>
            </div>
          </div>
          <Button>View All Complaints</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">{stats.resolved.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Resolved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">{stats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.avgTime}</p>
              <p className="text-xs text-muted-foreground">Avg Time</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">{stats.satisfaction}/5</p>
              <p className="text-xs text-muted-foreground">Satisfaction</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Issue Types */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Issue Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {issueTypes.map((issue) => (
                  <div key={issue.type} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground">{issue.type}</span>
                      <span className="text-muted-foreground">{issue.count}</span>
                    </div>
                    <Progress value={issue.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Complaints */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Complaints</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant={
                          complaint.priority === "high" ? "destructive" :
                          complaint.priority === "medium" ? "secondary" : "outline"
                        }>
                          {complaint.priority}
                        </Badge>
                        <Badge variant={
                          complaint.status === "resolved" ? "default" :
                          complaint.status === "in-progress" ? "secondary" : "outline"
                        }>
                          {complaint.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {complaint.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {complaint.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Assigned Officers */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Assigned Officers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {assignedOfficers.map((officer) => (
                <div key={officer.name} className="p-4 bg-secondary/30 rounded-lg">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{officer.name}</p>
                      <p className="text-xs text-muted-foreground">{officer.zone}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-warning">{officer.pending} pending</span>
                    <span className="text-success">{officer.resolved} resolved</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
