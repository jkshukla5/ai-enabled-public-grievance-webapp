import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Landmark, Clock, User, MapPin, FileText } from "lucide-react"

const stats = {
  total: 1892,
  resolved: 1456,
  pending: 205,
  urgent: 18,
  avgTime: "5.2 days",
  satisfaction: 3.5,
}

const recentComplaints = [
  { id: "GRV-1269", subject: "Birth certificate pending for 45 days", priority: "low", status: "pending", citizen: "Meera Devi", location: "Tehsil Office", time: "2 hours ago" },
  { id: "GRV-1265", subject: "Pension not received for 3 months", priority: "high", status: "in-progress", citizen: "Retired Teacher", location: "Treasury Office", time: "4 hours ago" },
  { id: "GRV-1261", subject: "Ration card correction needed", priority: "medium", status: "pending", citizen: "Sunita Sharma", location: "Food Department", time: "8 hours ago" },
  { id: "GRV-1257", subject: "Property registration delay", priority: "medium", status: "in-progress", citizen: "Property Buyer", location: "Registrar Office", time: "12 hours ago" },
  { id: "GRV-1253", subject: "Caste certificate application stuck", priority: "low", status: "resolved", citizen: "Student", location: "SDM Office", time: "1 day ago" },
]

const serviceTypes = [
  { type: "Certificates", count: 456, percentage: 32 },
  { type: "Pension/Benefits", count: 312, percentage: 22 },
  { type: "Ration Services", count: 234, percentage: 16 },
  { type: "Property Services", count: 267, percentage: 19 },
  { type: "License/Permits", count: 156, percentage: 11 },
]

const pendingApplications = [
  { type: "Birth Certificates", pending: 234, avgDays: 12 },
  { type: "Death Certificates", pending: 87, avgDays: 8 },
  { type: "Income Certificates", pending: 156, avgDays: 15 },
  { type: "Caste Certificates", pending: 198, avgDays: 18 },
  { type: "Domicile Certificates", pending: 123, avgDays: 14 },
]

export default function PublicServicesPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-chart-3/10 flex items-center justify-center">
              <Landmark className="w-6 h-6 text-chart-3" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Public Services</h1>
              <p className="text-muted-foreground">Government services and documentation complaints</p>
            </div>
          </div>
          <Button>View All Complaints</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">{stats.resolved.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Resolved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">{stats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.avgTime}</p>
              <p className="text-xs text-muted-foreground">Avg Time</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">{stats.satisfaction}/5</p>
              <p className="text-xs text-muted-foreground">Satisfaction</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pending Applications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <FileText className="w-4 h-4" />
                Pending Applications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingApplications.map((app) => (
                  <div key={app.type} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                    <div>
                      <p className="font-medium text-sm text-foreground">{app.type}</p>
                      <p className="text-xs text-muted-foreground">Avg wait: {app.avgDays} days</p>
                    </div>
                    <Badge variant="secondary">{app.pending} pending</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Complaints */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Complaints</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant={
                          complaint.priority === "high" ? "destructive" :
                          complaint.priority === "medium" ? "secondary" : "outline"
                        }>
                          {complaint.priority}
                        </Badge>
                        <Badge variant={
                          complaint.status === "resolved" ? "default" :
                          complaint.status === "in-progress" ? "secondary" : "outline"
                        }>
                          {complaint.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {complaint.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {complaint.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Service Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Service Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {serviceTypes.map((service) => (
                <div key={service.type} className="text-center p-4 bg-secondary/30 rounded-lg">
                  <p className="text-2xl font-bold text-foreground">{service.count}</p>
                  <p className="text-sm text-muted-foreground">{service.type}</p>
                  <Progress value={service.percentage} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
