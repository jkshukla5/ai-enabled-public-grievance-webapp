import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Droplets, Clock, User, MapPin } from "lucide-react"

const stats = {
  total: 2987,
  resolved: 2534,
  pending: 287,
  urgent: 32,
  avgTime: "1.8 days",
  satisfaction: 4.1,
}

const recentComplaints = [
  { id: "GRV-1266", subject: "No water supply in Gandhi Nagar since 3 days", priority: "high", status: "in-progress", citizen: "Priya Sharma", location: "Gandhi Nagar", time: "1 hour ago" },
  { id: "GRV-1264", subject: "Water contamination in tap water", priority: "high", status: "pending", citizen: "Health Officer", location: "Sector 22", time: "3 hours ago" },
  { id: "GRV-1262", subject: "Low water pressure in morning hours", priority: "medium", status: "in-progress", citizen: "Resident Association", location: "Model Town", time: "6 hours ago" },
  { id: "GRV-1260", subject: "Water meter showing incorrect readings", priority: "low", status: "pending", citizen: "Anita Rao", location: "Civil Lines", time: "10 hours ago" },
  { id: "GRV-1258", subject: "Pipeline leakage on main road", priority: "medium", status: "resolved", citizen: "Traffic Police", location: "MG Road", time: "14 hours ago" },
]

const issueTypes = [
  { type: "No Water Supply", count: 387, percentage: 32 },
  { type: "Low Pressure", count: 298, percentage: 25 },
  { type: "Contamination", count: 187, percentage: 15 },
  { type: "Leakage", count: 234, percentage: 19 },
  { type: "Billing Issues", count: 112, percentage: 9 },
]

const zoneStatus = [
  { zone: "Zone A - North", supply: "Normal", complaints: 45, status: "green" },
  { zone: "Zone B - South", supply: "Low Pressure", complaints: 78, status: "yellow" },
  { zone: "Zone C - East", supply: "Normal", complaints: 32, status: "green" },
  { zone: "Zone D - West", supply: "Disrupted", complaints: 132, status: "red" },
]

export default function WaterSupplyPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-info/10 flex items-center justify-center">
              <Droplets className="w-6 h-6 text-info" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Water Supply Department</h1>
              <p className="text-muted-foreground">Water distribution and quality complaints</p>
            </div>
          </div>
          <Button>View All Complaints</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">{stats.resolved.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Resolved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">{stats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.avgTime}</p>
              <p className="text-xs text-muted-foreground">Avg Time</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">{stats.satisfaction}/5</p>
              <p className="text-xs text-muted-foreground">Satisfaction</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Zone Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Zone Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {zoneStatus.map((zone) => (
                  <div key={zone.zone} className="p-3 bg-secondary/30 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">{zone.zone}</span>
                      <Badge variant={
                        zone.status === "green" ? "default" :
                        zone.status === "yellow" ? "secondary" : "destructive"
                      }>
                        {zone.supply}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{zone.complaints} complaints</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Complaints */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Complaints</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant={
                          complaint.priority === "high" ? "destructive" :
                          complaint.priority === "medium" ? "secondary" : "outline"
                        }>
                          {complaint.priority}
                        </Badge>
                        <Badge variant={
                          complaint.status === "resolved" ? "default" :
                          complaint.status === "in-progress" ? "secondary" : "outline"
                        }>
                          {complaint.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {complaint.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {complaint.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Issue Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Issue Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {issueTypes.map((issue) => (
                <div key={issue.type} className="text-center p-4 bg-secondary/30 rounded-lg">
                  <p className="text-2xl font-bold text-foreground">{issue.count}</p>
                  <p className="text-sm text-muted-foreground">{issue.type}</p>
                  <Progress value={issue.percentage} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
