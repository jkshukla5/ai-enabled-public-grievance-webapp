import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Trash2, Clock, User, MapPin, Truck } from "lucide-react"

const stats = {
  total: 2134,
  resolved: 1823,
  pending: 198,
  urgent: 28,
  avgTime: "2.1 days",
  satisfaction: 3.9,
}

const recentComplaints = [
  { id: "GRV-1268", subject: "Garbage not collected for over a week in Block C", priority: "medium", status: "pending", citizen: "John D'souza", location: "Block C, Sector 5", time: "2 hours ago" },
  { id: "GRV-1264", subject: "Sewage overflow on main street creating health hazard", priority: "high", status: "in-progress", citizen: "Rajesh Singh", location: "Main Street", time: "4 hours ago" },
  { id: "GRV-1260", subject: "Public toilet not cleaned for days", priority: "medium", status: "pending", citizen: "Market Association", location: "Central Market", time: "8 hours ago" },
  { id: "GRV-1256", subject: "Drain blocked causing water logging", priority: "high", status: "in-progress", citizen: "Ward Councillor", location: "Ward 12", time: "12 hours ago" },
  { id: "GRV-1252", subject: "Irregular garbage collection schedule", priority: "low", status: "resolved", citizen: "RWA President", location: "Model Town", time: "1 day ago" },
]

const issueTypes = [
  { type: "Garbage Collection", count: 456, percentage: 38 },
  { type: "Sewage/Drainage", count: 312, percentage: 26 },
  { type: "Public Toilets", count: 187, percentage: 16 },
  { type: "Street Cleaning", count: 145, percentage: 12 },
  { type: "Dustbin Issues", count: 98, percentage: 8 },
]

const vehicleStatus = [
  { vehicle: "GC-001", route: "Sector 1-5", status: "Active", collections: 45 },
  { vehicle: "GC-002", route: "Sector 6-10", status: "Active", collections: 38 },
  { vehicle: "GC-003", route: "Model Town", status: "Maintenance", collections: 0 },
  { vehicle: "GC-004", route: "Civil Lines", status: "Active", collections: 52 },
  { vehicle: "GC-005", route: "Industrial Area", status: "Active", collections: 28 },
]

export default function SanitationPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-chart-1/10 flex items-center justify-center">
              <Trash2 className="w-6 h-6 text-chart-1" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Sanitation Department</h1>
              <p className="text-muted-foreground">Waste management and cleanliness complaints</p>
            </div>
          </div>
          <Button>View All Complaints</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">{stats.resolved.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Resolved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">{stats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.avgTime}</p>
              <p className="text-xs text-muted-foreground">Avg Time</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">{stats.satisfaction}/5</p>
              <p className="text-xs text-muted-foreground">Satisfaction</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Vehicle Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Truck className="w-4 h-4" />
                Collection Vehicles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {vehicleStatus.map((vehicle) => (
                  <div key={vehicle.vehicle} className="p-3 bg-secondary/30 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-sm text-foreground">{vehicle.vehicle}</span>
                      <Badge variant={vehicle.status === "Active" ? "default" : "secondary"}>
                        {vehicle.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{vehicle.route}</p>
                    <p className="text-xs text-muted-foreground mt-1">{vehicle.collections} collections today</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Complaints */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Complaints</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant={
                          complaint.priority === "high" ? "destructive" :
                          complaint.priority === "medium" ? "secondary" : "outline"
                        }>
                          {complaint.priority}
                        </Badge>
                        <Badge variant={
                          complaint.status === "resolved" ? "default" :
                          complaint.status === "in-progress" ? "secondary" : "outline"
                        }>
                          {complaint.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {complaint.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {complaint.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Issue Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Issue Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {issueTypes.map((issue) => (
                <div key={issue.type} className="text-center p-4 bg-secondary/30 rounded-lg">
                  <p className="text-2xl font-bold text-foreground">{issue.count}</p>
                  <p className="text-sm text-muted-foreground">{issue.type}</p>
                  <Progress value={issue.percentage} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
