import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Construction, Clock, User, MapPin, HardHat } from "lucide-react"

const stats = {
  total: 2756,
  resolved: 2234,
  pending: 245,
  urgent: 38,
  avgTime: "4.5 days",
  satisfaction: 3.7,
}

const recentComplaints = [
  { id: "GRV-1270", subject: "Large pothole on main road causing accidents", priority: "high", status: "in-progress", citizen: "Amit Patel", location: "MG Road", time: "1 hour ago" },
  { id: "GRV-1267", subject: "Bridge structural damage reported", priority: "high", status: "pending", citizen: "Traffic Inspector", location: "River Bridge", time: "3 hours ago" },
  { id: "GRV-1263", subject: "Footpath tiles broken and dangerous", priority: "medium", status: "in-progress", citizen: "Pedestrian Association", location: "Market Area", time: "6 hours ago" },
  { id: "GRV-1259", subject: "Road construction blocking entrance", priority: "medium", status: "pending", citizen: "Shop Owners Association", location: "Commercial Street", time: "12 hours ago" },
  { id: "GRV-1255", subject: "Traffic signal not working at junction", priority: "high", status: "resolved", citizen: "Traffic Police", location: "Main Junction", time: "1 day ago" },
]

const issueTypes = [
  { type: "Potholes", count: 567, percentage: 35 },
  { type: "Road Repair", count: 423, percentage: 26 },
  { type: "Footpath Issues", count: 287, percentage: 18 },
  { type: "Traffic Signals", count: 198, percentage: 12 },
  { type: "Drainage", count: 145, percentage: 9 },
]

const ongoingProjects = [
  { project: "Highway Widening - Phase 2", location: "NH-48", progress: 72, deadline: "Jun 2026" },
  { project: "Flyover Construction", location: "Central Junction", progress: 45, deadline: "Aug 2026" },
  { project: "Road Resurfacing", location: "Model Town", progress: 88, deadline: "May 2026" },
  { project: "Footpath Renovation", location: "Market Area", progress: 34, deadline: "Jul 2026" },
]

export default function RoadsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-chart-4/10 flex items-center justify-center">
              <Construction className="w-6 h-6 text-chart-4" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Roads & Infrastructure</h1>
              <p className="text-muted-foreground">Road maintenance and construction complaints</p>
            </div>
          </div>
          <Button>View All Complaints</Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-success">{stats.resolved.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Resolved</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-warning">{stats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-foreground">{stats.avgTime}</p>
              <p className="text-xs text-muted-foreground">Avg Time</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-primary">{stats.satisfaction}/5</p>
              <p className="text-xs text-muted-foreground">Satisfaction</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Ongoing Projects */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <HardHat className="w-4 h-4" />
                Ongoing Projects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ongoingProjects.map((project) => (
                  <div key={project.project} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm text-foreground">{project.project}</span>
                      <Badge variant="secondary">{project.progress}%</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{project.location} | Due: {project.deadline}</p>
                    <Progress value={project.progress} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Complaints */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Complaints</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant={
                          complaint.priority === "high" ? "destructive" :
                          complaint.priority === "medium" ? "secondary" : "outline"
                        }>
                          {complaint.priority}
                        </Badge>
                        <Badge variant={
                          complaint.status === "resolved" ? "default" :
                          complaint.status === "in-progress" ? "secondary" : "outline"
                        }>
                          {complaint.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" /> {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {complaint.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {complaint.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Issue Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Issue Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {issueTypes.map((issue) => (
                <div key={issue.type} className="text-center p-4 bg-secondary/30 rounded-lg">
                  <p className="text-2xl font-bold text-foreground">{issue.count}</p>
                  <p className="text-sm text-muted-foreground">{issue.type}</p>
                  <Progress value={issue.percentage} className="h-2 mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
