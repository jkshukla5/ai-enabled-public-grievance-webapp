import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Settings, User, Bell, Shield, Database, Globe, Palette } from "lucide-react"

const settingsSections = [
  {
    icon: User,
    title: "Profile Settings",
    description: "Manage your account details and preferences",
    items: [
      { label: "Full Name", value: "Admin User", type: "text" },
      { label: "Email", value: "admin@janshikayat.gov.in", type: "email" },
      { label: "Phone", value: "+91 98765 43210", type: "tel" },
      { label: "Department", value: "System Administration", type: "text" },
    ]
  },
  {
    icon: Bell,
    title: "Notification Settings",
    description: "Configure how you receive alerts",
    items: [
      { label: "Email Notifications", value: true, type: "toggle" },
      { label: "SMS Alerts", value: true, type: "toggle" },
      { label: "Urgent Complaints", value: true, type: "toggle" },
      { label: "Daily Digest", value: false, type: "toggle" },
    ]
  },
  {
    icon: Shield,
    title: "Security Settings",
    description: "Manage security and access",
    items: [
      { label: "Two-Factor Auth", value: true, type: "toggle" },
      { label: "Session Timeout", value: "30 minutes", type: "select" },
      { label: "IP Whitelist", value: "Enabled", type: "toggle" },
    ]
  },
]

const systemSettings = [
  { icon: Database, title: "Database Backup", status: "Last backup: 2 hours ago", action: "Backup Now" },
  { icon: Globe, title: "Language Settings", status: "12 languages active", action: "Configure" },
  { icon: Palette, title: "Theme Settings", status: "Dark mode enabled", action: "Customize" },
]

export default function SettingsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Settings className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Settings</h1>
            <p className="text-muted-foreground">Manage system and account settings</p>
          </div>
        </div>

        {/* Profile & Notifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {settingsSections.slice(0, 2).map((section) => (
            <Card key={section.title}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base font-medium">
                  <section.icon className="w-4 h-4" />
                  {section.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{section.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {section.items.map((item) => (
                    <div key={item.label} className="flex items-center justify-between">
                      <label className="text-sm text-foreground">{item.label}</label>
                      {item.type === "toggle" ? (
                        <Button variant={item.value ? "default" : "outline"} size="sm">
                          {item.value ? "Enabled" : "Disabled"}
                        </Button>
                      ) : (
                        <Input defaultValue={item.value as string} className="w-48" />
                      )}
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-6">Save Changes</Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Shield className="w-4 h-4" />
              Security Settings
            </CardTitle>
            <p className="text-sm text-muted-foreground">Manage security and access controls</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {settingsSections[2].items.map((item) => (
                <div key={item.label} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                  <span className="text-sm text-foreground">{item.label}</span>
                  {item.type === "toggle" ? (
                    <Badge variant={item.value ? "default" : "secondary"}>
                      {item.value ? "Enabled" : "Disabled"}
                    </Badge>
                  ) : (
                    <Badge variant="outline">{item.value}</Badge>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 p-4 border border-warning/30 bg-warning/5 rounded-lg">
              <p className="text-sm text-warning font-medium">Security Recommendation</p>
              <p className="text-xs text-muted-foreground mt-1">
                Enable IP whitelisting for enhanced security. Only approved IP addresses will be able to access the system.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* System Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">System Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {systemSettings.map((setting) => (
                <div key={setting.title} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <setting.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{setting.title}</p>
                      <p className="text-xs text-muted-foreground">{setting.status}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">{setting.action}</Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
