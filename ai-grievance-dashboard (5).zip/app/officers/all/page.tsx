import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Users, Search, Filter, Mail, Phone, Building2, Star } from "lucide-react"

const officers = [
  { id: "OFF-001", name: "AE Rajesh Sharma", email: "rajesh.sharma@gov.in", phone: "+91 98765 43210", department: "Electricity", zone: "Zone 1", pending: 12, resolved: 245, rating: 4.5, status: "active" },
  { id: "OFF-002", name: "JE Priya Verma", email: "priya.verma@gov.in", phone: "+91 98765 43211", department: "Electricity", zone: "Zone 2", pending: 8, resolved: 198, rating: 4.7, status: "active" },
  { id: "OFF-003", name: "AE Amit Singh", email: "amit.singh@gov.in", phone: "+91 98765 43212", department: "Water Supply", zone: "Zone 1", pending: 15, resolved: 312, rating: 4.3, status: "active" },
  { id: "OFF-004", name: "JE Sunita Devi", email: "sunita.devi@gov.in", phone: "+91 98765 43213", department: "Water Supply", zone: "Zone 3", pending: 6, resolved: 187, rating: 4.8, status: "active" },
  { id: "OFF-005", name: "SO Mohan Kumar", email: "mohan.kumar@gov.in", phone: "+91 98765 43214", department: "Sanitation", zone: "All Zones", pending: 22, resolved: 456, rating: 4.2, status: "active" },
  { id: "OFF-006", name: "AE Kavita Patel", email: "kavita.patel@gov.in", phone: "+91 98765 43215", department: "Roads & Infra", zone: "Zone 2", pending: 18, resolved: 234, rating: 4.1, status: "on-leave" },
  { id: "OFF-007", name: "JE Ravi Yadav", email: "ravi.yadav@gov.in", phone: "+91 98765 43216", department: "Roads & Infra", zone: "Zone 4", pending: 9, resolved: 178, rating: 4.4, status: "active" },
  { id: "OFF-008", name: "SDM Anita Gupta", email: "anita.gupta@gov.in", phone: "+91 98765 43217", department: "Public Services", zone: "District HQ", pending: 34, resolved: 567, rating: 4.6, status: "active" },
]

const departmentColors: Record<string, string> = {
  "Electricity": "bg-warning/10 text-warning",
  "Water Supply": "bg-info/10 text-info",
  "Sanitation": "bg-chart-1/10 text-chart-1",
  "Roads & Infra": "bg-chart-4/10 text-chart-4",
  "Public Services": "bg-chart-3/10 text-chart-3",
}

export default function AllOfficersPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">All Officers</h1>
              <p className="text-muted-foreground">Government officers handling grievances</p>
            </div>
          </div>
          <Button>Add New Officer</Button>
        </div>

        {/* Search and Filter */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search officers..." className="pl-9" />
              </div>
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Officers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {officers.map((officer) => (
            <Card key={officer.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {officer.name.split(' ').slice(1).map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">{officer.name}</p>
                      <p className="text-xs text-muted-foreground">{officer.id}</p>
                    </div>
                  </div>
                  <Badge variant={officer.status === "active" ? "default" : "secondary"}>
                    {officer.status}
                  </Badge>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Building2 className="w-4 h-4 text-muted-foreground" />
                    <Badge className={departmentColors[officer.department]}>{officer.department}</Badge>
                    <span className="text-muted-foreground">| {officer.zone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    <span>{officer.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span>{officer.phone}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-warning">{officer.pending} pending</span>
                    <span className="text-success">{officer.resolved} resolved</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-warning text-warning" />
                    <span className="text-sm font-medium">{officer.rating}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </PageLayout>
  )
}
