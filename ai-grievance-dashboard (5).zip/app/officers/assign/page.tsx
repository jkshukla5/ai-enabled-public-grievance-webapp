import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { UserCog, ArrowRight, Clock, MapPin, AlertTriangle } from "lucide-react"

const unassignedComplaints = [
  { id: "GRV-1275", subject: "Street light pole damaged", department: "Electricity", priority: "medium", location: "Sector 22", time: "10 min ago" },
  { id: "GRV-1274", subject: "Water contamination reported", department: "Water Supply", priority: "high", location: "Gandhi Nagar", time: "15 min ago" },
  { id: "GRV-1273", subject: "Garbage not collected", department: "Sanitation", priority: "medium", location: "Model Town", time: "25 min ago" },
  { id: "GRV-1272", subject: "Pothole on highway", department: "Roads & Infra", priority: "high", location: "NH-48", time: "30 min ago" },
]

const availableOfficers = [
  { id: "OFF-001", name: "AE Rajesh Sharma", department: "Electricity", currentLoad: 12, maxLoad: 20, zone: "Zone 1" },
  { id: "OFF-002", name: "JE Priya Verma", department: "Electricity", currentLoad: 8, maxLoad: 15, zone: "Zone 2" },
  { id: "OFF-003", name: "AE Amit Singh", department: "Water Supply", currentLoad: 15, maxLoad: 20, zone: "Zone 1" },
  { id: "OFF-005", name: "SO Mohan Kumar", department: "Sanitation", currentLoad: 22, maxLoad: 30, zone: "All Zones" },
  { id: "OFF-007", name: "JE Ravi Yadav", department: "Roads & Infra", currentLoad: 9, maxLoad: 15, zone: "Zone 4" },
]

const recentAssignments = [
  { complaint: "GRV-1270", officer: "AE Sharma", department: "Electricity", assignedAt: "5 min ago" },
  { complaint: "GRV-1268", officer: "SO Kumar", department: "Sanitation", assignedAt: "12 min ago" },
  { complaint: "GRV-1266", officer: "AE Singh", department: "Water Supply", assignedAt: "18 min ago" },
  { complaint: "GRV-1264", officer: "JE Yadav", department: "Roads & Infra", assignedAt: "25 min ago" },
]

export default function AssignDutiesPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <UserCog className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Assign Duties</h1>
            <p className="text-muted-foreground">Assign complaints to officers manually</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Unassigned Complaints */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between text-base font-medium">
                <span>Unassigned Complaints</span>
                <Badge variant="destructive">{unassignedComplaints.length} pending</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {unassignedComplaints.map((complaint) => (
                  <div key={complaint.id} className="p-4 border border-border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-sm text-primary">{complaint.id}</span>
                      <Badge variant={complaint.priority === "high" ? "destructive" : "secondary"}>
                        {complaint.priority}
                      </Badge>
                    </div>
                    <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                      <Badge variant="outline">{complaint.department}</Badge>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {complaint.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {complaint.time}
                      </span>
                    </div>
                    <Button size="sm" className="w-full">
                      Assign Officer <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Available Officers */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Available Officers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {availableOfficers.map((officer) => {
                  const loadPercentage = (officer.currentLoad / officer.maxLoad) * 100
                  return (
                    <div key={officer.id} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {officer.name.split(' ').slice(1).map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-foreground">{officer.name}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Badge variant="outline" className="text-xs">{officer.department}</Badge>
                            <span>{officer.zone}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">
                          {officer.currentLoad}/{officer.maxLoad}
                        </p>
                        <p className={`text-xs ${loadPercentage > 80 ? "text-destructive" : loadPercentage > 60 ? "text-warning" : "text-success"}`}>
                          {loadPercentage > 80 ? "Heavy" : loadPercentage > 60 ? "Moderate" : "Light"} load
                        </p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Assignments */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Recent Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {recentAssignments.map((assignment) => (
                <div key={assignment.complaint} className="p-4 bg-success/5 border border-success/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-sm text-primary">{assignment.complaint}</span>
                    <span className="text-xs text-muted-foreground">{assignment.assignedAt}</span>
                  </div>
                  <p className="text-sm text-foreground">Assigned to <span className="font-medium">{assignment.officer}</span></p>
                  <Badge variant="outline" className="mt-2 text-xs">{assignment.department}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
