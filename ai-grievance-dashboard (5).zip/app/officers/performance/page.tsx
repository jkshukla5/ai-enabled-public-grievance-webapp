import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { FileSearch, Trophy, TrendingUp, Clock, Star, Medal } from "lucide-react"

const topPerformers = [
  { rank: 1, name: "JE Sunita Devi", department: "Water Supply", resolved: 187, avgTime: "1.2 days", rating: 4.8, badge: "gold" },
  { rank: 2, name: "JE Priya Verma", department: "Electricity", resolved: 198, avgTime: "1.4 days", rating: 4.7, badge: "silver" },
  { rank: 3, name: "SDM Anita Gupta", department: "Public Services", resolved: 567, avgTime: "2.1 days", rating: 4.6, badge: "bronze" },
  { rank: 4, name: "AE Rajesh Sharma", department: "Electricity", resolved: 245, avgTime: "1.8 days", rating: 4.5, badge: null },
  { rank: 5, name: "JE Ravi Yadav", department: "Roads & Infra", resolved: 178, avgTime: "2.4 days", rating: 4.4, badge: null },
]

const performanceMetrics = [
  { officer: "JE Sunita Devi", resolution: 94, response: 98, satisfaction: 96, overall: 96 },
  { officer: "JE Priya Verma", resolution: 92, response: 95, satisfaction: 94, overall: 94 },
  { officer: "SDM Anita Gupta", resolution: 89, response: 92, satisfaction: 92, overall: 91 },
  { officer: "AE Rajesh Sharma", resolution: 88, response: 90, satisfaction: 90, overall: 89 },
  { officer: "AE Amit Singh", resolution: 85, response: 88, satisfaction: 86, overall: 86 },
]

const monthlyProgress = [
  { month: "Jan", complaints: 1245, resolved: 1156, rate: 93 },
  { month: "Feb", complaints: 1367, resolved: 1289, rate: 94 },
  { month: "Mar", complaints: 1489, resolved: 1398, rate: 94 },
  { month: "Apr", complaints: 1523, resolved: 1456, rate: 96 },
  { month: "May", complaints: 1247, resolved: 1091, rate: 87 },
]

const badgeColors: Record<string, string> = {
  gold: "bg-warning text-warning-foreground",
  silver: "bg-muted text-muted-foreground",
  bronze: "bg-chart-4/20 text-chart-4",
}

export default function OfficerPerformancePage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <FileSearch className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Officer Performance</h1>
            <p className="text-muted-foreground">Track and analyze officer performance metrics</p>
          </div>
        </div>

        {/* Top Performers */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Trophy className="w-4 h-4 text-warning" />
              Top Performers This Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {topPerformers.map((officer) => (
                <div key={officer.rank} className={`p-4 rounded-lg ${officer.rank <= 3 ? "bg-warning/5 border border-warning/20" : "bg-secondary/30"}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {officer.badge ? (
                        <Medal className={`w-5 h-5 ${officer.badge === "gold" ? "text-warning" : officer.badge === "silver" ? "text-muted-foreground" : "text-chart-4"}`} />
                      ) : (
                        <span className="text-lg font-bold text-muted-foreground">#{officer.rank}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-warning text-warning" />
                      <span className="text-sm font-medium">{officer.rating}</span>
                    </div>
                  </div>
                  <Avatar className="w-12 h-12 mx-auto mb-2">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {officer.name.split(' ').slice(1).map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <p className="text-sm font-medium text-foreground text-center">{officer.name}</p>
                  <p className="text-xs text-muted-foreground text-center mb-2">{officer.department}</p>
                  <div className="text-center text-xs">
                    <span className="text-success">{officer.resolved} resolved</span>
                    <span className="text-muted-foreground mx-1">|</span>
                    <span className="text-foreground">{officer.avgTime}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Performance Scores</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {performanceMetrics.map((metric) => (
                  <div key={metric.officer} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">{metric.officer}</span>
                      <Badge variant="secondary">{metric.overall}%</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <p className="text-muted-foreground">Resolution</p>
                        <Progress value={metric.resolution} className="h-1.5 mt-1" />
                      </div>
                      <div>
                        <p className="text-muted-foreground">Response</p>
                        <Progress value={metric.response} className="h-1.5 mt-1" />
                      </div>
                      <div>
                        <p className="text-muted-foreground">Satisfaction</p>
                        <Progress value={metric.satisfaction} className="h-1.5 mt-1" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Monthly Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <TrendingUp className="w-4 h-4" />
                Monthly Resolution Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {monthlyProgress.map((month) => (
                  <div key={month.month} className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground w-10">{month.month}</span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="flex-1 bg-secondary rounded-full h-2">
                          <div 
                            className="bg-chart-1 h-2 rounded-full" 
                            style={{ width: `${(month.complaints / 1600) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground w-12">{month.complaints}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-secondary rounded-full h-2">
                          <div 
                            className="bg-success h-2 rounded-full" 
                            style={{ width: `${(month.resolved / 1600) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-success w-12">{month.resolved}</span>
                      </div>
                    </div>
                    <Badge variant={month.rate >= 90 ? "default" : "secondary"}>{month.rate}%</Badge>
                  </div>
                ))}
                <div className="flex items-center gap-4 pt-2 border-t border-border text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-chart-1" />
                    <span className="text-muted-foreground">Total</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-success" />
                    <span className="text-muted-foreground">Resolved</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
