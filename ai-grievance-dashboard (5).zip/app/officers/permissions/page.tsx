import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Shield, Check, X, Users, Settings } from "lucide-react"

const roles = [
  {
    name: "Super Admin",
    description: "Full system access",
    users: 2,
    permissions: ["all"],
  },
  {
    name: "Department Head",
    description: "Department-level management",
    users: 5,
    permissions: ["view_complaints", "assign_officers", "resolve_complaints", "view_analytics", "manage_officers"],
  },
  {
    name: "Senior Officer",
    description: "Handle and resolve complaints",
    users: 12,
    permissions: ["view_complaints", "resolve_complaints", "reassign_complaints", "view_analytics"],
  },
  {
    name: "Junior Officer",
    description: "Basic complaint handling",
    users: 28,
    permissions: ["view_complaints", "resolve_complaints", "add_comments"],
  },
  {
    name: "Viewer",
    description: "Read-only access",
    users: 8,
    permissions: ["view_complaints", "view_analytics"],
  },
]

const allPermissions = [
  { key: "view_complaints", label: "View Complaints", description: "Access complaint details" },
  { key: "resolve_complaints", label: "Resolve Complaints", description: "Mark complaints as resolved" },
  { key: "assign_officers", label: "Assign Officers", description: "Assign complaints to officers" },
  { key: "reassign_complaints", label: "Reassign Complaints", description: "Transfer complaints between officers" },
  { key: "add_comments", label: "Add Comments", description: "Add notes to complaints" },
  { key: "view_analytics", label: "View Analytics", description: "Access dashboard analytics" },
  { key: "manage_officers", label: "Manage Officers", description: "Add/edit officer profiles" },
  { key: "system_settings", label: "System Settings", description: "Configure system settings" },
  { key: "all", label: "All Permissions", description: "Full system access" },
]

export default function PermissionsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Permissions</h1>
              <p className="text-muted-foreground">Manage roles and access control</p>
            </div>
          </div>
          <Button>
            <Settings className="w-4 h-4 mr-2" />
            Create Role
          </Button>
        </div>

        {/* Roles Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {roles.map((role) => (
            <Card key={role.name}>
              <CardContent className="p-4 text-center">
                <h3 className="font-medium text-foreground">{role.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{role.description}</p>
                <div className="flex items-center justify-center gap-1 mt-3">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-foreground">{role.users} users</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Permissions Matrix */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Permissions Matrix</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground">Permission</th>
                    {roles.map((role) => (
                      <th key={role.name} className="text-center py-3 px-4 text-muted-foreground">
                        {role.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {allPermissions.filter(p => p.key !== "all").map((permission) => (
                    <tr key={permission.key} className="border-b border-border/50">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-medium text-foreground">{permission.label}</p>
                          <p className="text-xs text-muted-foreground">{permission.description}</p>
                        </div>
                      </td>
                      {roles.map((role) => (
                        <td key={role.name} className="py-3 px-4 text-center">
                          {role.permissions.includes("all") || role.permissions.includes(permission.key) ? (
                            <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-success/10">
                              <Check className="w-4 h-4 text-success" />
                            </div>
                          ) : (
                            <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-muted">
                              <X className="w-4 h-4 text-muted-foreground" />
                            </div>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
