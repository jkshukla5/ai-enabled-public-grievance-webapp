import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get total complaints
    const { count: totalComplaints } = await supabase
      .from('complaints')
      .select('*', { count: 'exact', head: true })

    // Get resolved complaints
    const { count: resolved } = await supabase
      .from('complaints')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'resolved')

    // Get pending complaints
    const { count: pending } = await supabase
      .from('complaints')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending')

    // Get urgent complaints
    const { count: urgent } = await supabase
      .from('complaints')
      .select('*', { count: 'exact', head: true })
      .eq('priority', 'high')

    // Get department stats
    const { data: complaintsByDept } = await supabase
      .from('complaints')
      .select('department')

    const departmentStats: Record<string, number> = {}
    complaintsByDept?.forEach((c) => {
      departmentStats[c.department] = (departmentStats[c.department] || 0) + 1
    })

    // Get today's stats
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const { count: todayComplaints } = await supabase
      .from('complaints')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', today.toISOString())

    return NextResponse.json({
      success: true,
      stats: {
        totalComplaints: totalComplaints || 0,
        resolved: resolved || 0,
        pending: pending || 0,
        urgent: urgent || 0,
        todayComplaints: todayComplaints || 0,
        departmentStats,
      },
    })
  } catch (error) {
    console.error('[v0] Error fetching stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch statistics' },
      { status: 500 }
    )
  }
}
