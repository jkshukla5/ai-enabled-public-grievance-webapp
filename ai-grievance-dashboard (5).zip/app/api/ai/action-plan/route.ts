import { streamText } from 'ai'

export async function POST(request: Request) {
  const { complaint } = await request.json()

  const prompt = `Analyze this citizen complaint and generate a detailed resolution action plan.

Complaint: "${complaint}"

Provide a step-by-step action plan in JSON format:
{
  "steps": [
    {"step": 1, "action": "description", "timeframe": "estimated time"},
    ...
  ],
  "estimatedResolutionTime": "timeframe",
  "requiredResources": ["resource1", "resource2"],
  "riskFactors": ["risk1", "risk2"],
  "alternativeSolutions": ["solution1", "solution2"]
}

Provide ONLY the JSON response.`

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    prompt,
    temperature: 0.5,
  })

  return result.toDataStreamResponse()
}
