import { streamText } from 'ai'

export async function POST(request: Request) {
  const { complaint, language } = await request.json()

  const prompt = `You are an expert government complaint classifier. Analyze this citizen complaint and classify it.

Language: ${language}
Complaint: "${complaint}"

Respond in JSON format with:
{
  "department": "Electricity|Water Supply|Sanitation|Roads & Infrastructure|Public Services",
  "category": "specific category",
  "priority": "high|medium|low",
  "urgency": "urgent|normal|low",
  "summary": "brief summary in 2-3 sentences",
  "keywords": ["keyword1", "keyword2"],
  "suggestedAction": "recommended action"
}

Provide ONLY the JSON response, no additional text.`

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    prompt,
    temperature: 0.3,
  })

  return result.toDataStreamResponse()
}
