import { streamText } from 'ai'

export async function POST(request: Request) {
  const { complaint, department } = await request.json()

  const prompt = `You are a government complaint response specialist. Generate a professional response to this citizen complaint.

Department: ${department}
Complaint: "${complaint}"

Write a professional, empathetic response that:
1. Acknowledges the complaint
2. Shows understanding of the issue
3. Explains next steps
4. Provides estimated timeline
5. Includes contact information format

Keep it concise (150-200 words) and in professional government tone.`

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    prompt,
    temperature: 0.7,
  })

  return result.toDataStreamResponse()
}
