import { streamText } from 'ai'

export async function POST(request: Request) {
  const { text, targetLanguage } = await request.json()

  const prompt = `Translate the following text to ${targetLanguage}. Maintain the formal tone and meaning.

Text: "${text}"

Provide ONLY the translated text, no additional commentary.`

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    prompt,
    temperature: 0.3,
  })

  return result.toDataStreamResponse()
}
