import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const supabase = await createClient()
    
    // Test connection by querying citizens
    const { data, error } = await supabase
      .from('citizens')
      .select('count')
      .limit(1)

    if (error) {
      console.error('[v0] Test connection error:', error)
      return NextResponse.json({ 
        success: false, 
        error: error.message 
      }, { status: 500 })
    }

    console.log('[v0] Supabase connection successful')
    return NextResponse.json({ 
      success: true, 
      message: 'Supabase connection working',
      data 
    })
  } catch (error) {
    console.error('[v0] Test endpoint error:', error)
    return NextResponse.json({ 
      success: false, 
      error: String(error) 
    }, { status: 500 })
  }
}
