import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()

    const { searchParams } = new URL(request.url)
    const complaintId = searchParams.get('id')
    const trackingId = searchParams.get('trackingId')

    if (!complaintId && !trackingId) {
      return NextResponse.json(
        { error: 'Missing complaint ID or tracking ID' },
        { status: 400 }
      )
    }

    let query = supabase.from('complaints').select(`
      *,
      citizens (
        id,
        name,
        phone,
        email,
        address
      ),
      complaint_history (
        id,
        status,
        remarks,
        updated_by,
        created_at
      )
    `)

    if (complaintId) {
      query = query.eq('complaint_id', complaintId)
    } else {
      query = query.eq('id', trackingId)
    }

    const { data, error } = await query.single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      data,
    })
  } catch (error) {
    console.error('[v0] Error tracking complaint:', error)
    return NextResponse.json(
      { error: 'Complaint not found' },
      { status: 404 }
    )
  }
}
