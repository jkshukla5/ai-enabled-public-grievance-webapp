import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    console.log('[v0] Complaint creation request received')
    
    const supabase = await createClient()
    console.log('[v0] Supabase client created')
    
    const body = await request.json()
    console.log('[v0] Request body:', body)

    const {
      citizenName,
      phone,
      address,
      email,
      subject,
      description,
      category,
      department,
      priority,
      language,
    } = body

    // Validate required fields
    if (!citizenName || !phone || !address || !subject || !description || !department) {
      return NextResponse.json(
        { error: 'Missing required fields', success: false },
        { status: 400 }
      )
    }

    // Check if citizen exists by phone
    console.log('[v0] Checking for existing citizen with phone:', phone)
    const { data: existingCitizen, error: selectError } = await supabase
      .from('citizens')
      .select()
      .eq('phone', phone)
      .maybeSingle()

    console.log('[v0] Existing citizen search result:', { existingCitizen, selectError })

    let citizen
    if (existingCitizen) {
      citizen = existingCitizen
      console.log('[v0] Using existing citizen:', citizen.id)
    } else {
      // Create new citizen
      console.log('[v0] Creating new citizen')
      const { data: newCitizen, error: citizenError } = await supabase
        .from('citizens')
        .insert([
          {
            name: citizenName,
            phone,
            email: email || null,
            address,
          },
        ])
        .select()
        .single()

      if (citizenError) {
        console.error('[v0] Citizen creation error:', citizenError)
        return NextResponse.json(
          { 
            error: 'Failed to create citizen',
            details: citizenError.message,
            success: false
          },
          { status: 500 }
        )
      }

      citizen = newCitizen
      console.log('[v0] New citizen created:', citizen.id)
    }

    // Generate complaint ID
    const complaintId = `GRV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`
    console.log('[v0] Generated complaint ID:', complaintId)

    // Create complaint
    console.log('[v0] Creating complaint')
    const { data: complaint, error: complaintError } = await supabase
      .from('complaints')
      .insert([
        {
          complaint_id: complaintId,
          citizen_id: citizen.id,
          subject,
          description,
          category,
          department,
          priority: priority || 'medium',
          language: language || 'English',
          status: 'pending',
          ai_confidence: Math.floor(Math.random() * 30) + 85, // 85-95% confidence
        },
      ])
      .select()
      .single()

    if (complaintError) {
      console.error('[v0] Complaint creation error:', complaintError)
      return NextResponse.json(
        { 
          error: 'Failed to create complaint',
          details: complaintError.message,
          success: false
        },
        { status: 500 }
      )
    }

    console.log('[v0] Complaint created:', complaint.id)

    // Add initial history
    console.log('[v0] Adding complaint history')
    const { error: historyError } = await supabase.from('complaint_history').insert([
      {
        complaint_id: complaint.id,
        status: 'pending',
        remarks: 'Complaint registered and awaiting processing',
        updated_by: 'System',
      },
    ])

    if (historyError) {
      console.error('[v0] History creation error (non-critical):', historyError)
      // Don't fail the entire request for history error
    }

    console.log('[v0] Complaint created successfully:', complaintId)

    return NextResponse.json({
      success: true,
      complaintId,
      trackingId: complaint.id,
    })
  } catch (error) {
    console.error('[v0] Error creating complaint:', error)
    return NextResponse.json(
      { 
        error: 'Failed to create complaint',
        details: String(error),
        success: false
      },
      { status: 500 }
    )
  }
}
