import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { HelpCircle, Search, Book, Video, MessageSquare, Phone, Mail, FileText } from "lucide-react"

const faqs = [
  { question: "How does AI classify complaints?", answer: "The AI analyzes complaint text in multiple languages, identifies keywords, and routes to appropriate departments with confidence scores." },
  { question: "What happens if AI classification is wrong?", answer: "Officers can manually reassign complaints. The AI learns from corrections to improve accuracy over time." },
  { question: "How are urgent complaints identified?", answer: "Keywords like 'emergency', 'hospital', 'danger' automatically flag complaints as urgent for immediate attention." },
  { question: "Can citizens track their complaints?", answer: "Yes, citizens receive SMS updates and can track status via the public portal using their complaint ID." },
  { question: "What languages are supported?", answer: "The system supports Hindi, English, and 10+ regional languages including Tamil, Telugu, Marathi, and more." },
]

const resources = [
  { icon: Book, title: "User Manual", description: "Complete guide to using the system", link: "#" },
  { icon: Video, title: "Video Tutorials", description: "Step-by-step video guides", link: "#" },
  { icon: FileText, title: "API Documentation", description: "Technical integration docs", link: "#" },
  { icon: MessageSquare, title: "Knowledge Base", description: "Articles and best practices", link: "#" },
]

const contactOptions = [
  { icon: Phone, title: "Phone Support", value: "1800-XXX-XXXX", subtitle: "Mon-Sat, 9 AM - 6 PM" },
  { icon: Mail, title: "Email Support", value: "support@janshikayat.gov.in", subtitle: "Response within 24 hours" },
  { icon: MessageSquare, title: "Live Chat", value: "Available Now", subtitle: "Instant support" },
]

export default function HelpPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <HelpCircle className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Help Center</h1>
            <p className="text-muted-foreground">Get help and support for the grievance system</p>
          </div>
        </div>

        {/* Search */}
        <Card>
          <CardContent className="p-6">
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input placeholder="Search for help topics..." className="pl-12 h-12 text-lg" />
            </div>
          </CardContent>
        </Card>

        {/* Resources */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {resources.map((resource) => (
            <Card key={resource.title} className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <resource.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-medium text-foreground">{resource.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{resource.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* FAQs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {faqs.map((faq, index) => (
                  <div key={index} className="p-4 bg-secondary/30 rounded-lg">
                    <p className="font-medium text-foreground mb-2">{faq.question}</p>
                    <p className="text-sm text-muted-foreground">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contact Support */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Contact Support</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {contactOptions.map((option) => (
                  <div key={option.title} className="flex items-center gap-4 p-4 bg-secondary/30 rounded-lg">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <option.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{option.title}</p>
                      <p className="text-sm text-primary">{option.value}</p>
                      <p className="text-xs text-muted-foreground">{option.subtitle}</p>
                    </div>
                    <Button variant="outline" size="sm">Contact</Button>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 border border-border rounded-lg">
                <h4 className="font-medium text-foreground mb-2">Submit a Support Ticket</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Can&apos;t find what you&apos;re looking for? Submit a ticket and our team will help.
                </p>
                <Button className="w-full">Create Support Ticket</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
