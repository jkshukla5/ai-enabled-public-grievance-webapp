'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Spinner } from '@/components/ui/spinner'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Brain, Copy, Check, AlertCircle } from 'lucide-react'
import {
  useComplaintClassification,
  useTranslation,
  useActionPlanGeneration,
  useResponseGeneration,
} from '@/hooks/use-ai-features'

export default function AIAssistantPage() {
  const [complaint, setComplaint] = useState('')
  const [language, setLanguage] = useState('English')
  const [targetLanguage, setTargetLanguage] = useState('Hindi')
  const [copied, setCopied] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState('classify')

  const { classify, isLoading: classifyLoading, classification, error: classifyError } = useComplaintClassification()
  const { translate, isLoading: translateLoading, translation, error: translateError } = useTranslation()
  const { generatePlan, isLoading: planLoading, actionPlan, error: planError } = useActionPlanGeneration()
  const { generateResponse, isLoading: responseLoading, response, error: responseError } = useResponseGeneration()

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const handleClassify = async () => {
    if (complaint.trim()) {
      await classify(complaint, language)
      setActiveTab('result')
    }
  }

  const handleTranslate = async () => {
    if (complaint.trim()) {
      await translate(complaint, targetLanguage)
    }
  }

  const handleGeneratePlan = async () => {
    if (complaint.trim()) {
      await generatePlan(complaint)
    }
  }

  const handleGenerateResponse = async () => {
    if (complaint.trim() && classification?.department) {
      await generateResponse(complaint, classification.department)
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 p-6">
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Brain className="w-6 h-6 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">AI Assistant</h1>
        </div>
        <p className="text-muted-foreground">
          Powered by AI Gateway - Classify, translate, and analyze complaints
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="border-border lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Complaint Input</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
              >
                <option>English</option>
                <option>Hindi</option>
                <option>Bengali</option>
                <option>Telugu</option>
                <option>Tamil</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Complaint Text
              </label>
              <Textarea
                value={complaint}
                onChange={(e) => setComplaint(e.target.value)}
                placeholder="Enter a citizen complaint..."
                className="min-h-[150px]"
              />
            </div>

            {complaint && (
              <div className="text-xs text-muted-foreground">
                {complaint.length} characters
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-border lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">AI Features</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="classify">Classify</TabsTrigger>
                <TabsTrigger value="translate">Translate</TabsTrigger>
                <TabsTrigger value="plan">Action Plan</TabsTrigger>
                <TabsTrigger value="response">Response</TabsTrigger>
              </TabsList>

              <TabsContent value="classify" className="space-y-4 mt-4">
                {classifyError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{classifyError}</AlertDescription>
                  </Alert>
                )}
                {classification ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Department</p>
                        <Badge className="bg-primary/20 text-primary">
                          {classification.department}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Priority</p>
                        <Badge
                          variant={
                            classification.priority === 'high'
                              ? 'destructive'
                              : 'default'
                          }
                        >
                          {classification.priority}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Category</p>
                      <p className="text-sm">{classification.category}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Summary</p>
                      <p className="text-sm text-foreground">{classification.summary}</p>
                    </div>
                  </div>
                ) : (
                  <Button
                    onClick={handleClassify}
                    disabled={classifyLoading || !complaint}
                    className="w-full"
                  >
                    {classifyLoading ? (
                      <>
                        <Spinner className="w-4 h-4 mr-2" />
                        Classifying...
                      </>
                    ) : (
                      'Classify Complaint'
                    )}
                  </Button>
                )}
              </TabsContent>

              <TabsContent value="translate" className="space-y-4 mt-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    Target Language
                  </label>
                  <select
                    value={targetLanguage}
                    onChange={(e) => setTargetLanguage(e.target.value)}
                    className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                  >
                    <option>Hindi</option>
                    <option>Bengali</option>
                    <option>Telugu</option>
                    <option>Tamil</option>
                    <option>English</option>
                  </select>
                </div>
                {translateError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{translateError}</AlertDescription>
                  </Alert>
                )}
                {translation ? (
                  <div className="space-y-2">
                    <div className="bg-secondary p-3 rounded-lg">
                      <p className="text-sm text-foreground">{translation}</p>
                    </div>
                    <Button
                      onClick={() => handleCopy(translation, 'translation')}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      {copied === 'translation' ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Translation
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={handleTranslate}
                    disabled={translateLoading || !complaint}
                    className="w-full"
                  >
                    {translateLoading ? (
                      <>
                        <Spinner className="w-4 h-4 mr-2" />
                        Translating...
                      </>
                    ) : (
                      'Translate to ' + targetLanguage
                    )}
                  </Button>
                )}
              </TabsContent>

              <TabsContent value="plan" className="space-y-4 mt-4">
                {planError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{planError}</AlertDescription>
                  </Alert>
                )}
                {actionPlan ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">
                        Estimated Resolution Time
                      </p>
                      <Badge>{actionPlan.estimatedResolutionTime}</Badge>
                    </div>
                    {actionPlan.steps && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-2">
                          Action Steps
                        </p>
                        <div className="space-y-2">
                          {actionPlan.steps.map(
                            (step: any, idx: number) => (
                              <div
                                key={idx}
                                className="text-sm border-l-2 border-primary pl-3"
                              >
                                <p className="font-medium">
                                  Step {step.step}: {step.action}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {step.timeframe}
                                </p>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <Button
                    onClick={handleGeneratePlan}
                    disabled={planLoading || !complaint}
                    className="w-full"
                  >
                    {planLoading ? (
                      <>
                        <Spinner className="w-4 h-4 mr-2" />
                        Generating...
                      </>
                    ) : (
                      'Generate Action Plan'
                    )}
                  </Button>
                )}
              </TabsContent>

              <TabsContent value="response" className="space-y-4 mt-4">
                {responseError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{responseError}</AlertDescription>
                  </Alert>
                )}
                {response ? (
                  <div className="space-y-2">
                    <div className="bg-secondary p-3 rounded-lg max-h-64 overflow-y-auto">
                      <p className="text-sm text-foreground whitespace-pre-wrap">
                        {response}
                      </p>
                    </div>
                    <Button
                      onClick={() => handleCopy(response, 'response')}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      {copied === 'response' ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy Response
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={handleGenerateResponse}
                    disabled={responseLoading || !complaint || !classification}
                    className="w-full"
                  >
                    {responseLoading ? (
                      <>
                        <Spinner className="w-4 h-4 mr-2" />
                        Generating...
                      </>
                    ) : !classification ? (
                      'Classify First'
                    ) : (
                      'Generate Response'
                    )}
                  </Button>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
