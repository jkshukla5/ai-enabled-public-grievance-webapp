"use client"

import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"

export default function AIAssistantLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-background">
      <DashboardSidebar />
      <div className="flex-1 overflow-hidden flex flex-col">
        <DashboardHeader />
        <main className="overflow-y-auto flex-1">
          {children}
        </main>
      </div>
    </div>
  )
}
