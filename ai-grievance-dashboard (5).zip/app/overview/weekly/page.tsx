import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Calendar, Target, Clock, CheckCircle } from "lucide-react"

const weeklyStats = [
  { label: "Total Complaints", value: "1,247", change: "+18.3%", trend: "up" },
  { label: "Resolution Rate", value: "78.5%", change: "+5.2%", trend: "up" },
  { label: "Avg. Resolution Time", value: "2.4 days", change: "-12%", trend: "down" },
  { label: "Citizen Satisfaction", value: "4.2/5", change: "+0.3", trend: "up" },
]

const dailyBreakdown = [
  { day: "Monday", received: 198, resolved: 156, pending: 42 },
  { day: "Tuesday", received: 212, resolved: 178, pending: 34 },
  { day: "Wednesday", received: 187, resolved: 165, pending: 22 },
  { day: "Thursday", received: 224, resolved: 189, pending: 35 },
  { day: "Friday", received: 196, resolved: 167, pending: 29 },
  { day: "Saturday", received: 142, resolved: 118, pending: 24 },
  { day: "Sunday", received: 88, resolved: 72, pending: 16 },
]

const topIssues = [
  { issue: "Power outages in residential areas", count: 156, department: "Electricity" },
  { issue: "Water supply interruptions", count: 134, department: "Water Supply" },
  { issue: "Pothole complaints on main roads", count: 98, department: "Roads & Infra" },
  { issue: "Garbage collection delays", count: 87, department: "Sanitation" },
  { issue: "Street light maintenance", count: 76, department: "Electricity" },
]

export default function WeeklyReportPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Weekly Report</h1>
            <p className="text-muted-foreground">Performance summary for the current week</p>
          </div>
          <Badge variant="outline" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            May 3 - May 9, 2026
          </Badge>
        </div>

        {/* Weekly Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {weeklyStats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                <div className="flex items-center gap-1 mt-2">
                  {stat.trend === "up" ? (
                    <TrendingUp className="w-4 h-4 text-success" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-success" />
                  )}
                  <span className="text-sm text-success">{stat.change}</span>
                  <span className="text-sm text-muted-foreground">vs last week</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Daily Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Daily Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Day</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Received</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Resolved</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Pending</th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {dailyBreakdown.map((day) => (
                    <tr key={day.day} className="border-b border-border/50">
                      <td className="py-3 px-4 text-sm font-medium text-foreground">{day.day}</td>
                      <td className="py-3 px-4 text-sm text-center text-foreground">{day.received}</td>
                      <td className="py-3 px-4 text-sm text-center text-success">{day.resolved}</td>
                      <td className="py-3 px-4 text-sm text-center text-warning">{day.pending}</td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="secondary">
                          {Math.round((day.resolved / day.received) * 100)}%
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Top Issues */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Target className="w-4 h-4" />
              Top Issues This Week
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topIssues.map((issue, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                  <div className="flex items-center gap-4">
                    <span className="text-2xl font-bold text-muted-foreground">#{index + 1}</span>
                    <div>
                      <p className="font-medium text-foreground">{issue.issue}</p>
                      <p className="text-sm text-muted-foreground">{issue.department}</p>
                    </div>
                  </div>
                  <Badge variant="outline">{issue.count} complaints</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
