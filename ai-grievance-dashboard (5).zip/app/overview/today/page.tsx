import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Clock, CheckCircle, AlertTriangle, TrendingUp, Users, Building2 } from "lucide-react"

const todayStats = [
  { label: "Complaints Received", value: 156, icon: Clock, change: "+23" },
  { label: "Resolved Today", value: 89, icon: CheckCircle, change: "+12" },
  { label: "Pending Action", value: 67, icon: AlertTriangle, change: "-8" },
  { label: "Officers Active", value: 42, icon: Users, change: "+5" },
]

const hourlyData = [
  { hour: "6 AM", received: 8, resolved: 5 },
  { hour: "7 AM", received: 12, resolved: 8 },
  { hour: "8 AM", received: 24, resolved: 15 },
  { hour: "9 AM", received: 32, resolved: 22 },
  { hour: "10 AM", received: 28, resolved: 19 },
  { hour: "11 AM", received: 22, resolved: 12 },
  { hour: "12 PM", received: 18, resolved: 8 },
  { hour: "1 PM", received: 12, resolved: 0 },
]

const departmentToday = [
  { name: "Electricity", received: 42, resolved: 28, pending: 14, progress: 67 },
  { name: "Water Supply", received: 38, resolved: 22, pending: 16, progress: 58 },
  { name: "Sanitation", received: 28, resolved: 18, pending: 10, progress: 64 },
  { name: "Roads & Infra", received: 32, resolved: 15, pending: 17, progress: 47 },
  { name: "Public Services", received: 16, resolved: 6, pending: 10, progress: 38 },
]

export default function TodaySummaryPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Today&apos;s Summary</h1>
          <p className="text-muted-foreground">Real-time overview of today&apos;s grievance activity</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {todayStats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                    <Badge variant="secondary" className="mt-2">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      {stat.change} from yesterday
                    </Badge>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Hourly Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Hourly Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {hourlyData.map((item) => (
                <div key={item.hour} className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground w-16">{item.hour}</span>
                  <div className="flex-1 flex items-center gap-2">
                    <div className="flex-1 bg-secondary rounded-full h-2">
                      <div 
                        className="bg-chart-1 h-2 rounded-full" 
                        style={{ width: `${(item.received / 35) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-foreground w-8">{item.received}</span>
                  </div>
                  <div className="flex-1 flex items-center gap-2">
                    <div className="flex-1 bg-secondary rounded-full h-2">
                      <div 
                        className="bg-success h-2 rounded-full" 
                        style={{ width: `${(item.resolved / 35) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-foreground w-8">{item.resolved}</span>
                  </div>
                </div>
              ))}
              <div className="flex items-center gap-4 pt-2 border-t border-border">
                <span className="text-sm text-muted-foreground w-16"></span>
                <div className="flex-1 flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-chart-1" />
                  <span className="text-sm text-muted-foreground">Received</span>
                </div>
                <div className="flex-1 flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-success" />
                  <span className="text-sm text-muted-foreground">Resolved</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Department Progress Today */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Building2 className="w-4 h-4" />
              Department Progress Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {departmentToday.map((dept) => (
                <div key={dept.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground">{dept.name}</span>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-muted-foreground">
                        {dept.resolved}/{dept.received} resolved
                      </span>
                      <Badge variant={dept.progress >= 60 ? "default" : "secondary"}>
                        {dept.progress}%
                      </Badge>
                    </div>
                  </div>
                  <Progress value={dept.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
