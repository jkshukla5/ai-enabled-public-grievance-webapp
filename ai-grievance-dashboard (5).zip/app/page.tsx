import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { GrievanceChart } from "@/components/dashboard/grievance-chart"
import { ClassificationStats } from "@/components/dashboard/classification-stats"
import { AIMetrics } from "@/components/dashboard/ai-metrics"
import { GrievanceTable } from "@/components/dashboard/grievance-table"
import { ActivityFeed } from "@/components/dashboard/activity-feed"

export default function DashboardPage() {
  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          <StatsCards />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <GrievanceChart />
            </div>
            <div>
              <ClassificationStats />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <GrievanceTable />
            </div>
            <div className="space-y-6">
              <AIMetrics />
              <ActivityFeed />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
