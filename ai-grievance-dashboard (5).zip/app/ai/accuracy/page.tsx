import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Target, TrendingUp, AlertCircle, CheckCircle, XCircle } from "lucide-react"

const overallAccuracy = {
  classification: 97.2,
  routing: 94.8,
  priority: 92.5,
  language: 99.1,
}

const departmentAccuracy = [
  { name: "Electricity", accuracy: 98.2, samples: 3456, correct: 3394 },
  { name: "Water Supply", accuracy: 96.8, samples: 2987, correct: 2891 },
  { name: "Sanitation", accuracy: 95.4, samples: 2134, correct: 2036 },
  { name: "Roads & Infra", accuracy: 97.1, samples: 2756, correct: 2676 },
  { name: "Public Services", accuracy: 93.2, samples: 1892, correct: 1763 },
]

const confusionMatrix = [
  { actual: "Electricity", electricity: 3394, water: 32, sanitation: 12, roads: 8, public: 10 },
  { actual: "Water Supply", electricity: 45, water: 2891, sanitation: 28, roads: 15, public: 8 },
  { actual: "Sanitation", electricity: 18, water: 42, sanitation: 2036, roads: 25, public: 13 },
  { actual: "Roads & Infra", electricity: 12, water: 18, sanitation: 32, roads: 2676, public: 18 },
  { actual: "Public Services", electricity: 22, water: 35, sanitation: 28, roads: 44, public: 1763 },
]

const recentMisclassifications = [
  { id: "GRV-1198", original: "Water Supply", corrected: "Sanitation", reason: "Sewage mentioned but categorized as water" },
  { id: "GRV-1187", original: "Electricity", corrected: "Public Services", reason: "Streetlight complaint near govt office" },
  { id: "GRV-1176", original: "Roads & Infra", corrected: "Sanitation", reason: "Drainage issue on road" },
  { id: "GRV-1165", original: "Public Services", corrected: "Water Supply", reason: "Water bill complaint" },
]

export default function AccuracyReportPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">AI Accuracy Report</h1>
          <p className="text-muted-foreground">Classification accuracy metrics and analysis</p>
        </div>

        {/* Overall Accuracy Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {Object.entries(overallAccuracy).map(([key, value]) => (
            <Card key={key}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-muted-foreground capitalize">{key} Accuracy</p>
                  <Target className="w-4 h-4 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">{value}%</p>
                <Progress value={value} className="h-2 mt-3" />
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="w-3 h-3 text-success" />
                  <span className="text-xs text-success">+0.3% this week</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Department Accuracy */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Department-wise Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {departmentAccuracy.map((dept) => (
                  <div key={dept.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">{dept.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {dept.correct}/{dept.samples}
                        </span>
                        <Badge variant={dept.accuracy >= 95 ? "default" : "secondary"}>
                          {dept.accuracy}%
                        </Badge>
                      </div>
                    </div>
                    <Progress value={dept.accuracy} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Misclassifications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <AlertCircle className="w-4 h-4 text-warning" />
                Recent Corrections
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentMisclassifications.map((item) => (
                  <div key={item.id} className="p-4 bg-warning/5 border border-warning/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-mono text-sm text-primary">{item.id}</span>
                    </div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-destructive border-destructive/30">
                        <XCircle className="w-3 h-3 mr-1" />
                        {item.original}
                      </Badge>
                      <span className="text-muted-foreground">→</span>
                      <Badge variant="outline" className="text-success border-success/30">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        {item.corrected}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{item.reason}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Confusion Matrix */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Confusion Matrix</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground">Actual / Predicted</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Electricity</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Water</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Sanitation</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Roads</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Public</th>
                  </tr>
                </thead>
                <tbody>
                  {confusionMatrix.map((row) => (
                    <tr key={row.actual} className="border-b border-border/50">
                      <td className="py-3 px-4 font-medium text-foreground">{row.actual}</td>
                      <td className={`py-3 px-4 text-center ${row.actual === "Electricity" ? "bg-success/10 font-bold text-success" : "text-muted-foreground"}`}>
                        {row.electricity}
                      </td>
                      <td className={`py-3 px-4 text-center ${row.actual === "Water Supply" ? "bg-success/10 font-bold text-success" : "text-muted-foreground"}`}>
                        {row.water}
                      </td>
                      <td className={`py-3 px-4 text-center ${row.actual === "Sanitation" ? "bg-success/10 font-bold text-success" : "text-muted-foreground"}`}>
                        {row.sanitation}
                      </td>
                      <td className={`py-3 px-4 text-center ${row.actual === "Roads & Infra" ? "bg-success/10 font-bold text-success" : "text-muted-foreground"}`}>
                        {row.roads}
                      </td>
                      <td className={`py-3 px-4 text-center ${row.actual === "Public Services" ? "bg-success/10 font-bold text-success" : "text-muted-foreground"}`}>
                        {row.public}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
