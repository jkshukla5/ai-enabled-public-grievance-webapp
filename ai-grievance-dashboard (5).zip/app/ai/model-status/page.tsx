import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Cpu, Activity, Zap, Database, RefreshCw, CheckCircle, Clock, AlertCircle } from "lucide-react"

const modelStatus = {
  name: "GrievanceClassifier v3.2",
  status: "operational",
  uptime: "99.97%",
  lastTrained: "2026-05-07",
  totalPredictions: "1,247,832",
  todayPredictions: "3,456",
}

const modelMetrics = [
  { label: "CPU Usage", value: 34, unit: "%", status: "normal" },
  { label: "Memory Usage", value: 62, unit: "%", status: "normal" },
  { label: "GPU Utilization", value: 78, unit: "%", status: "normal" },
  { label: "Queue Length", value: 12, unit: "items", status: "normal" },
]

const recentActivity = [
  { time: "Just now", action: "Processed batch of 15 complaints", status: "success" },
  { time: "2 min ago", action: "Auto-routed 8 complaints to Electricity Dept", status: "success" },
  { time: "5 min ago", action: "Language detection: 12 Hindi, 3 English", status: "success" },
  { time: "12 min ago", action: "Model confidence check passed", status: "success" },
  { time: "25 min ago", action: "Retrained on 500 new samples", status: "success" },
  { time: "1 hour ago", action: "Backup model synced", status: "warning" },
]

const models = [
  { name: "Text Classifier", version: "v3.2", accuracy: 97.2, status: "active" },
  { name: "Language Detector", version: "v2.1", accuracy: 99.1, status: "active" },
  { name: "Priority Predictor", version: "v1.8", accuracy: 94.5, status: "active" },
  { name: "Sentiment Analyzer", version: "v2.0", accuracy: 91.3, status: "standby" },
]

export default function ModelStatusPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">AI Model Status</h1>
            <p className="text-muted-foreground">Monitor AI classification engine performance</p>
          </div>
          <Badge variant="default" className="bg-success text-success-foreground">
            <CheckCircle className="w-4 h-4 mr-1" />
            All Systems Operational
          </Badge>
        </div>

        {/* Main Model Status */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Cpu className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{modelStatus.name}</h2>
                  <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                    <span>Uptime: {modelStatus.uptime}</span>
                    <span>Last Trained: {modelStatus.lastTrained}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Today&apos;s Predictions</p>
                <p className="text-3xl font-bold text-foreground">{modelStatus.todayPredictions}</p>
                <p className="text-xs text-muted-foreground">Total: {modelStatus.totalPredictions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {modelMetrics.map((metric) => (
            <Card key={metric.label}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <Badge variant="secondary">{metric.status}</Badge>
                </div>
                <p className="text-2xl font-bold text-foreground mb-2">
                  {metric.value}{metric.unit === "%" ? "%" : ` ${metric.unit}`}
                </p>
                {metric.unit === "%" && <Progress value={metric.value} className="h-2" />}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Models List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Database className="w-4 h-4" />
                Active Models
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {models.map((model) => (
                  <div key={model.name} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{model.name}</p>
                      <p className="text-sm text-muted-foreground">Version {model.version}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">{model.accuracy}%</p>
                        <p className="text-xs text-muted-foreground">Accuracy</p>
                      </div>
                      <Badge variant={model.status === "active" ? "default" : "secondary"}>
                        {model.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Activity className="w-4 h-4" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${activity.status === "success" ? "bg-success" : "bg-warning"}`} />
                    <div className="flex-1">
                      <p className="text-sm text-foreground">{activity.action}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
