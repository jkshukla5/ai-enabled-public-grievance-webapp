import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { GitBranch, Zap, Droplets, Trash2, Construction, Landmark, Settings, CheckCircle, ArrowRight } from "lucide-react"

const routingRules = [
  {
    department: "Electricity",
    icon: Zap,
    keywords: ["बिजली", "electricity", "power", "transformer", "wire", "current", "voltage", "light", "streetlight", "meter"],
    autoRoute: true,
    threshold: 85,
    dailyRouted: 312,
  },
  {
    department: "Water Supply",
    icon: Droplets,
    keywords: ["पानी", "water", "supply", "tap", "pipe", "leak", "pressure", "tank", "bore", "well"],
    autoRoute: true,
    threshold: 85,
    dailyRouted: 287,
  },
  {
    department: "Sanitation",
    icon: Trash2,
    keywords: ["कचरा", "garbage", "waste", "sewage", "drain", "cleaning", "dustbin", "sweeper", "toilet"],
    autoRoute: true,
    threshold: 80,
    dailyRouted: 198,
  },
  {
    department: "Roads & Infrastructure",
    icon: Construction,
    keywords: ["सड़क", "road", "pothole", "bridge", "footpath", "divider", "construction", "repair"],
    autoRoute: true,
    threshold: 80,
    dailyRouted: 245,
  },
  {
    department: "Public Services",
    icon: Landmark,
    keywords: ["certificate", "license", "pension", "ration", "permit", "registration", "document"],
    autoRoute: false,
    threshold: 75,
    dailyRouted: 205,
  },
]

const routingStats = {
  totalRouted: 1247,
  autoRouted: 1089,
  manualReview: 158,
  accuracy: 94.8,
}

const recentRouting = [
  { id: "GRV-1256", text: "बिजली का बिल गलत आया है", department: "Electricity", confidence: 92.3, status: "auto" },
  { id: "GRV-1255", text: "Road has big pothole near market", department: "Roads & Infra", confidence: 97.8, status: "auto" },
  { id: "GRV-1254", text: "पानी में बदबू आ रही है", department: "Water Supply", confidence: 89.5, status: "auto" },
  { id: "GRV-1253", text: "Need birth certificate urgently", department: "Public Services", confidence: 78.2, status: "manual" },
]

export default function RoutingRulesPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">AI Routing Rules</h1>
            <p className="text-muted-foreground">Configure automatic complaint routing to departments</p>
          </div>
          <Button>
            <Settings className="w-4 h-4 mr-2" />
            Configure Rules
          </Button>
        </div>

        {/* Routing Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground">Total Routed Today</p>
              <p className="text-3xl font-bold text-foreground">{routingStats.totalRouted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground">Auto Routed</p>
              <p className="text-3xl font-bold text-success">{routingStats.autoRouted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground">Manual Review</p>
              <p className="text-3xl font-bold text-warning">{routingStats.manualReview}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground">Routing Accuracy</p>
              <p className="text-3xl font-bold text-primary">{routingStats.accuracy}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Routing Rules */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <GitBranch className="w-4 h-4" />
              Department Routing Rules
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {routingRules.map((rule) => (
                <div key={rule.department} className="p-4 border border-border rounded-lg">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <rule.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium text-foreground">{rule.department}</h3>
                        <p className="text-sm text-muted-foreground">Threshold: {rule.threshold}%</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{rule.dailyRouted} today</Badge>
                      <Badge variant={rule.autoRoute ? "default" : "outline"}>
                        {rule.autoRoute ? "Auto Route" : "Manual Review"}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {rule.keywords.map((keyword) => (
                      <Badge key={keyword} variant="outline" className="text-xs">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Routing Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Recent Routing Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentRouting.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
                  <div className="flex items-center gap-4">
                    <span className="font-mono text-sm text-primary">{item.id}</span>
                    <p className="text-sm text-foreground max-w-md truncate">{item.text}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                    <Badge variant="outline">{item.department}</Badge>
                    <Badge variant={item.status === "auto" ? "default" : "secondary"}>
                      {item.confidence}%
                    </Badge>
                    {item.status === "auto" && <CheckCircle className="w-4 h-4 text-success" />}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
