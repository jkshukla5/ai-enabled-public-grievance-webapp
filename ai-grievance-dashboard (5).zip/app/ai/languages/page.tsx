import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Languages, Globe, CheckCircle, Clock, TrendingUp } from "lucide-react"

const supportedLanguages = [
  { name: "Hindi", code: "hi", complaints: 4567, accuracy: 98.2, status: "active" },
  { name: "English", code: "en", complaints: 3245, accuracy: 99.1, status: "active" },
  { name: "Marathi", code: "mr", complaints: 1234, accuracy: 96.5, status: "active" },
  { name: "Tamil", code: "ta", complaints: 987, accuracy: 95.8, status: "active" },
  { name: "Telugu", code: "te", complaints: 876, accuracy: 94.2, status: "active" },
  { name: "Kannada", code: "kn", complaints: 654, accuracy: 93.1, status: "active" },
  { name: "Bengali", code: "bn", complaints: 543, accuracy: 92.8, status: "active" },
  { name: "Gujarati", code: "gu", complaints: 432, accuracy: 91.5, status: "beta" },
  { name: "Punjabi", code: "pa", complaints: 321, accuracy: 90.2, status: "beta" },
  { name: "Malayalam", code: "ml", complaints: 234, accuracy: 89.5, status: "beta" },
  { name: "Odia", code: "or", complaints: 123, accuracy: 87.2, status: "beta" },
  { name: "Urdu", code: "ur", complaints: 98, accuracy: 85.1, status: "beta" },
]

const languageStats = {
  totalLanguages: 12,
  activeLanguages: 7,
  avgAccuracy: 94.3,
  dailyProcessed: 1247,
}

const recentTranslations = [
  { original: "बिजली की समस्या है मेरे क्षेत्र में", translated: "There is electricity problem in my area", language: "Hindi", confidence: 98.5 },
  { original: "पाणी नाही येत आहे", translated: "Water is not coming", language: "Marathi", confidence: 97.2 },
  { original: "சாலை சரியில்லை", translated: "Road is not good", language: "Tamil", confidence: 96.8 },
  { original: "કચરો ઉપાડવામાં આવતો નથી", translated: "Garbage is not being picked up", language: "Gujarati", confidence: 94.5 },
]

export default function LanguageSupportPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Language Support</h1>
          <p className="text-muted-foreground">Multilingual processing capabilities for citizen complaints</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Languages</p>
                  <p className="text-2xl font-bold text-foreground">{languageStats.totalLanguages}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-success/10 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Languages</p>
                  <p className="text-2xl font-bold text-foreground">{languageStats.activeLanguages}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-info/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-info" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg Accuracy</p>
                  <p className="text-2xl font-bold text-foreground">{languageStats.avgAccuracy}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-warning/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Daily Processed</p>
                  <p className="text-2xl font-bold text-foreground">{languageStats.dailyProcessed}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Supported Languages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Languages className="w-4 h-4" />
                Supported Languages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {supportedLanguages.map((lang) => (
                  <div key={lang.code} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                        {lang.code.toUpperCase()}
                      </span>
                      <div>
                        <p className="font-medium text-foreground">{lang.name}</p>
                        <p className="text-xs text-muted-foreground">{lang.complaints.toLocaleString()} complaints</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">{lang.accuracy}%</p>
                        <p className="text-xs text-muted-foreground">accuracy</p>
                      </div>
                      <Badge variant={lang.status === "active" ? "default" : "secondary"}>
                        {lang.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Translations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Translations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTranslations.map((item, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">{item.language}</Badge>
                      <span className="text-sm text-primary font-medium">{item.confidence}% confidence</span>
                    </div>
                    <div className="space-y-2">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Original</p>
                        <p className="text-sm text-foreground bg-secondary/50 p-2 rounded">{item.original}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Translated</p>
                        <p className="text-sm text-foreground bg-primary/5 p-2 rounded border border-primary/20">{item.translated}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
