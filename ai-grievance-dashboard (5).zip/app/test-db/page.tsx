'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function TestPage() {
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const testConnection = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/test-connection')
      const data = await response.json()
      setResult(JSON.stringify(data, null, 2))
      console.log('[v0] Test result:', data)
    } catch (error) {
      setResult('Error: ' + String(error))
      console.error('[v0] Test error:', error)
    } finally {
      setLoading(false)
    }
  }

  const testComplaintCreation = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/complaints/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          citizenName: 'Test User',
          phone: '9999999999',
          address: 'Test Address',
          email: 'test@example.com',
          subject: 'Test Complaint',
          description: 'This is a test complaint',
          category: 'electricity',
          department: 'electricity',
          priority: 'low',
          language: 'English',
        }),
      })
      const data = await response.json()
      setResult(JSON.stringify(data, null, 2))
      console.log('[v0] Create result:', data)
    } catch (error) {
      setResult('Error: ' + String(error))
      console.error('[v0] Create error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Database Connection Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={testConnection} disabled={loading}>
              Test Supabase Connection
            </Button>
            <Button onClick={testComplaintCreation} disabled={loading} variant="secondary">
              Test Create Complaint
            </Button>
          </div>
          <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg overflow-auto max-h-96 text-sm">
            {result || 'No results yet. Click a button to test.'}
          </pre>
        </CardContent>
      </Card>
    </div>
  )
}
