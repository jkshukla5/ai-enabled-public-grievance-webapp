import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, AlertTriangle, CheckCircle, Info, Clock, Trash2 } from "lucide-react"

const notifications = [
  { id: 1, type: "urgent", title: "Critical: Hospital power outage", message: "GRV-1247 requires immediate attention - hospital affected", time: "5 min ago", read: false },
  { id: 2, type: "success", title: "Complaint Resolved", message: "GRV-1238 has been successfully resolved by AE Sharma", time: "15 min ago", read: false },
  { id: 3, type: "info", title: "New Assignment", message: "3 new complaints assigned to your department", time: "30 min ago", read: false },
  { id: 4, type: "warning", title: "SLA Warning", message: "GRV-1232 approaching SLA deadline in 2 hours", time: "1 hour ago", read: true },
  { id: 5, type: "success", title: "AI Model Updated", message: "Hindi language model has been retrained with improved accuracy", time: "2 hours ago", read: true },
  { id: 6, type: "info", title: "Weekly Report Ready", message: "Your weekly performance report is now available", time: "3 hours ago", read: true },
  { id: 7, type: "urgent", title: "Escalation Required", message: "GRV-1225 escalated to District Collector level", time: "4 hours ago", read: true },
  { id: 8, type: "success", title: "Batch Processing Complete", message: "58 complaints processed and routed successfully", time: "5 hours ago", read: true },
]

const typeIcons = {
  urgent: AlertTriangle,
  success: CheckCircle,
  info: Info,
  warning: Clock,
}

const typeStyles = {
  urgent: "bg-destructive/10 text-destructive border-destructive/20",
  success: "bg-success/10 text-success border-success/20",
  info: "bg-info/10 text-info border-info/20",
  warning: "bg-warning/10 text-warning border-warning/20",
}

export default function NotificationsPage() {
  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Bell className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Notifications</h1>
              <p className="text-muted-foreground">Stay updated with system alerts</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="destructive">{unreadCount} unread</Badge>
            <Button variant="outline" size="sm">Mark all read</Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">All Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {notifications.map((notification) => {
                const Icon = typeIcons[notification.type as keyof typeof typeIcons]
                return (
                  <div
                    key={notification.id}
                    className={`flex items-start gap-4 p-4 rounded-lg border ${
                      notification.read ? "bg-secondary/20 border-border" : "bg-card border-primary/20"
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${typeStyles[notification.type as keyof typeof typeStyles]}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className={`font-medium ${notification.read ? "text-muted-foreground" : "text-foreground"}`}>
                          {notification.title}
                        </p>
                        {!notification.read && (
                          <Badge variant="default" className="text-xs">New</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{notification.message}</p>
                      <p className="text-xs text-muted-foreground mt-2">{notification.time}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="shrink-0">
                      <Trash2 className="w-4 h-4 text-muted-foreground" />
                    </Button>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
