import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { LineChart, TrendingUp, TrendingDown, Calendar, ArrowUp, ArrowDown } from "lucide-react"

const monthlyTrends = [
  { month: "Jan 2026", received: 3245, resolved: 2987, rate: 92 },
  { month: "Feb 2026", received: 3567, resolved: 3234, rate: 91 },
  { month: "Mar 2026", received: 3890, resolved: 3567, rate: 92 },
  { month: "Apr 2026", received: 4123, resolved: 3890, rate: 94 },
  { month: "May 2026", received: 4456, resolved: 4123, rate: 93 },
]

const categoryTrends = [
  { category: "Power Outages", thisMonth: 456, lastMonth: 389, change: "+17.2%" },
  { category: "Water Supply Issues", thisMonth: 387, lastMonth: 412, change: "-6.1%" },
  { category: "Road Repairs", thisMonth: 298, lastMonth: 256, change: "+16.4%" },
  { category: "Garbage Collection", thisMonth: 234, lastMonth: 267, change: "-12.4%" },
  { category: "Document Services", thisMonth: 189, lastMonth: 178, change: "+6.2%" },
]

const peakHours = [
  { hour: "9 AM - 10 AM", complaints: 234, percentage: 18 },
  { hour: "10 AM - 11 AM", complaints: 198, percentage: 15 },
  { hour: "11 AM - 12 PM", complaints: 167, percentage: 13 },
  { hour: "2 PM - 3 PM", complaints: 156, percentage: 12 },
  { hour: "4 PM - 5 PM", complaints: 145, percentage: 11 },
]

const weekdayDistribution = [
  { day: "Monday", complaints: 312, percentage: 18 },
  { day: "Tuesday", complaints: 298, percentage: 17 },
  { day: "Wednesday", complaints: 276, percentage: 16 },
  { day: "Thursday", complaints: 289, percentage: 17 },
  { day: "Friday", complaints: 267, percentage: 15 },
  { day: "Saturday", complaints: 178, percentage: 10 },
  { day: "Sunday", complaints: 127, percentage: 7 },
]

export default function TrendsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Trends Analysis</h1>
            <p className="text-muted-foreground">Historical patterns and forecasting</p>
          </div>
          <Badge variant="outline" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Last 6 Months
          </Badge>
        </div>

        {/* Monthly Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <LineChart className="w-4 h-4" />
              Monthly Complaint Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {monthlyTrends.map((month, index) => (
                <div key={month.month} className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground w-20">{month.month}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex-1 bg-secondary rounded-full h-3">
                        <div
                          className="bg-chart-1 h-3 rounded-full"
                          style={{ width: `${(month.received / 5000) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-foreground w-12">{month.received}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-secondary rounded-full h-3">
                        <div
                          className="bg-success h-3 rounded-full"
                          style={{ width: `${(month.resolved / 5000) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-success w-12">{month.resolved}</span>
                    </div>
                  </div>
                  <Badge variant="secondary">{month.rate}%</Badge>
                </div>
              ))}
              <div className="flex items-center gap-4 pt-2 border-t border-border">
                <span className="text-sm text-muted-foreground w-20"></span>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-chart-1" />
                    <span className="text-muted-foreground">Received</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-success" />
                    <span className="text-muted-foreground">Resolved</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Category Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Category Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categoryTrends.map((item) => (
                  <div key={item.category} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{item.category}</p>
                      <p className="text-sm text-muted-foreground">
                        {item.thisMonth} this month vs {item.lastMonth} last month
                      </p>
                    </div>
                    <Badge
                      variant="secondary"
                      className={item.change.startsWith("+") ? "text-success" : "text-destructive"}
                    >
                      {item.change.startsWith("+") ? (
                        <ArrowUp className="w-3 h-3 mr-1" />
                      ) : (
                        <ArrowDown className="w-3 h-3 mr-1" />
                      )}
                      {item.change}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Peak Hours */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Peak Complaint Hours</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {peakHours.map((item, index) => (
                  <div key={item.hour} className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground w-28">{item.hour}</span>
                    <div className="flex-1 bg-secondary rounded-full h-4">
                      <div
                        className="bg-primary h-4 rounded-full flex items-center justify-end pr-2"
                        style={{ width: `${item.percentage * 5}%` }}
                      >
                        {item.percentage >= 12 && (
                          <span className="text-xs text-primary-foreground">{item.complaints}</span>
                        )}
                      </div>
                    </div>
                    {item.percentage < 12 && (
                      <span className="text-sm text-foreground w-10">{item.complaints}</span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Weekday Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Weekday Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-4">
              {weekdayDistribution.map((item) => (
                <div key={item.day} className="text-center">
                  <div
                    className="bg-primary/20 rounded-lg mb-2 mx-auto transition-all hover:bg-primary/30"
                    style={{ height: `${item.percentage * 8}px`, width: "40px" }}
                  />
                  <p className="text-sm font-medium text-foreground">{item.complaints}</p>
                  <p className="text-xs text-muted-foreground">{item.day.substring(0, 3)}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
