import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, Target, Clock, Users, Award, Star } from "lucide-react"

const kpis = [
  { label: "Overall Resolution Rate", value: 87.5, target: 90, unit: "%" },
  { label: "Average Response Time", value: 2.4, target: 2, unit: "hours" },
  { label: "Citizen Satisfaction", value: 4.2, target: 4.5, unit: "/5" },
  { label: "First Contact Resolution", value: 62, target: 70, unit: "%" },
]

const performanceMetrics = [
  { metric: "Complaints Received", current: 1247, previous: 1056, change: "+18.1%" },
  { metric: "Complaints Resolved", current: 1091, previous: 923, change: "+18.2%" },
  { metric: "Avg Resolution Time", current: "2.4 days", previous: "2.8 days", change: "-14.3%" },
  { metric: "Escalation Rate", current: "8.2%", previous: "12.5%", change: "-34.4%" },
  { metric: "Auto-Resolution", current: "34.5%", previous: "28.2%", change: "+22.3%" },
  { metric: "Citizen Feedback Rate", current: "45%", previous: "38%", change: "+18.4%" },
]

const topPerformers = [
  { name: "Electricity Department", score: 94, resolved: 312, avgTime: "1.2 days" },
  { name: "Water Supply", score: 89, resolved: 287, avgTime: "1.8 days" },
  { name: "Sanitation", score: 85, resolved: 198, avgTime: "2.1 days" },
  { name: "Roads & Infrastructure", score: 78, resolved: 245, avgTime: "4.5 days" },
  { name: "Public Services", score: 72, resolved: 205, avgTime: "5.2 days" },
]

const slaCompliance = [
  { priority: "Critical (< 4 hrs)", compliance: 94, total: 156, met: 147 },
  { priority: "High (< 24 hrs)", compliance: 88, total: 342, met: 301 },
  { priority: "Medium (< 72 hrs)", compliance: 92, total: 567, met: 522 },
  { priority: "Low (< 7 days)", compliance: 96, total: 182, met: 175 },
]

export default function PerformancePage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Performance Analytics</h1>
          <p className="text-muted-foreground">System-wide performance metrics and KPIs</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi) => {
            const percentage = kpi.unit === "%" || kpi.unit === "/5"
              ? (kpi.value / (kpi.unit === "/5" ? 5 : 100)) * 100
              : (kpi.target / kpi.value) * 100
            const isOnTarget = kpi.unit === "hours" ? kpi.value <= kpi.target : kpi.value >= kpi.target
            
            return (
              <Card key={kpi.label}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-muted-foreground">{kpi.label}</p>
                    <Target className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <p className="text-3xl font-bold text-foreground">
                    {kpi.value}{kpi.unit}
                  </p>
                  <div className="flex items-center justify-between mt-2 text-sm">
                    <span className="text-muted-foreground">Target: {kpi.target}{kpi.unit}</span>
                    <Badge variant={isOnTarget ? "default" : "secondary"}>
                      {isOnTarget ? "On Track" : "Below Target"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <TrendingUp className="w-4 h-4" />
                Performance vs Last Month
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {performanceMetrics.map((metric) => (
                  <div key={metric.metric} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{metric.metric}</p>
                      <p className="text-sm text-muted-foreground">
                        Previous: {metric.previous}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-foreground">{metric.current}</p>
                      <Badge
                        variant="secondary"
                        className={metric.change.startsWith("+") && !metric.metric.includes("Time") && !metric.metric.includes("Escalation")
                          ? "text-success"
                          : metric.change.startsWith("-") && (metric.metric.includes("Time") || metric.metric.includes("Escalation"))
                          ? "text-success"
                          : "text-destructive"
                        }
                      >
                        {metric.change}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Performers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Award className="w-4 h-4" />
                Department Rankings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topPerformers.map((dept, index) => (
                  <div key={dept.name} className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      index === 0 ? "bg-warning/20 text-warning" :
                      index === 1 ? "bg-muted text-muted-foreground" :
                      index === 2 ? "bg-chart-4/20 text-chart-4" :
                      "bg-secondary text-muted-foreground"
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{dept.name}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>{dept.resolved} resolved</span>
                        <span>Avg: {dept.avgTime}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-foreground">{dept.score}</p>
                      <p className="text-xs text-muted-foreground">score</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* SLA Compliance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <Clock className="w-4 h-4" />
              SLA Compliance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {slaCompliance.map((sla) => (
                <div key={sla.priority} className="text-center">
                  <div className="relative w-24 h-24 mx-auto mb-3">
                    <svg className="w-24 h-24 transform -rotate-90">
                      <circle
                        cx="48"
                        cy="48"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-secondary"
                      />
                      <circle
                        cx="48"
                        cy="48"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        strokeDasharray={`${sla.compliance * 2.51} 251`}
                        className={sla.compliance >= 90 ? "text-success" : sla.compliance >= 80 ? "text-warning" : "text-destructive"}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl font-bold text-foreground">{sla.compliance}%</span>
                    </div>
                  </div>
                  <p className="text-sm font-medium text-foreground">{sla.priority}</p>
                  <p className="text-xs text-muted-foreground">{sla.met}/{sla.total} met</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
