import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { PieChart, TrendingUp, TrendingDown, Clock, CheckCircle, AlertTriangle } from "lucide-react"

const departmentStats = [
  {
    name: "Electricity",
    total: 3456,
    resolved: 3012,
    pending: 312,
    avgTime: "1.2 days",
    satisfaction: 4.3,
    trend: "+12%",
    trendDirection: "up",
  },
  {
    name: "Water Supply",
    total: 2987,
    resolved: 2534,
    pending: 287,
    avgTime: "1.8 days",
    satisfaction: 4.1,
    trend: "+8%",
    trendDirection: "up",
  },
  {
    name: "Sanitation",
    total: 2134,
    resolved: 1823,
    pending: 198,
    avgTime: "2.1 days",
    satisfaction: 3.9,
    trend: "+5%",
    trendDirection: "up",
  },
  {
    name: "Roads & Infrastructure",
    total: 2756,
    resolved: 2234,
    pending: 245,
    avgTime: "4.5 days",
    satisfaction: 3.7,
    trend: "-3%",
    trendDirection: "down",
  },
  {
    name: "Public Services",
    total: 1892,
    resolved: 1456,
    pending: 205,
    avgTime: "5.2 days",
    satisfaction: 3.5,
    trend: "+2%",
    trendDirection: "up",
  },
]

const topComplaints = {
  Electricity: ["Power outages", "Street lights", "Meter issues", "Billing errors"],
  "Water Supply": ["No supply", "Low pressure", "Contamination", "Leakage"],
  Sanitation: ["Garbage collection", "Sewage overflow", "Drain cleaning", "Public toilets"],
  "Roads & Infrastructure": ["Potholes", "Road repair", "Footpath damage", "Traffic signals"],
  "Public Services": ["Certificate delays", "Pension issues", "License renewal", "Documentation"],
}

export default function DepartmentStatsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Department Statistics</h1>
          <p className="text-muted-foreground">Comprehensive analytics by government department</p>
        </div>

        {/* Department Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {departmentStats.map((dept) => (
            <Card key={dept.name}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-medium">{dept.name}</CardTitle>
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {dept.trendDirection === "up" ? (
                      <TrendingUp className="w-3 h-3 text-success" />
                    ) : (
                      <TrendingDown className="w-3 h-3 text-destructive" />
                    )}
                    {dept.trend}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-3 bg-secondary/30 rounded-lg">
                    <p className="text-2xl font-bold text-foreground">{dept.total.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Total</p>
                  </div>
                  <div className="text-center p-3 bg-success/10 rounded-lg">
                    <p className="text-2xl font-bold text-success">{dept.resolved.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Resolved</p>
                  </div>
                  <div className="text-center p-3 bg-warning/10 rounded-lg">
                    <p className="text-2xl font-bold text-warning">{dept.pending}</p>
                    <p className="text-xs text-muted-foreground">Pending</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2">
                      <Clock className="w-4 h-4" /> Avg. Resolution
                    </span>
                    <span className="font-medium text-foreground">{dept.avgTime}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" /> Resolution Rate
                    </span>
                    <span className="font-medium text-foreground">
                      {Math.round((dept.resolved / dept.total) * 100)}%
                    </span>
                  </div>
                  <Progress value={(dept.resolved / dept.total) * 100} className="h-2" />
                </div>

                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-2">Top Complaint Types</p>
                  <div className="flex flex-wrap gap-2">
                    {topComplaints[dept.name as keyof typeof topComplaints].map((complaint) => (
                      <Badge key={complaint} variant="outline" className="text-xs">
                        {complaint}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Comparison Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <PieChart className="w-4 h-4" />
              Department Comparison
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground">Department</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Total</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Resolved</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Pending</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Avg Time</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Satisfaction</th>
                    <th className="text-center py-3 px-4 text-muted-foreground">Trend</th>
                  </tr>
                </thead>
                <tbody>
                  {departmentStats.map((dept) => (
                    <tr key={dept.name} className="border-b border-border/50">
                      <td className="py-3 px-4 font-medium text-foreground">{dept.name}</td>
                      <td className="py-3 px-4 text-center text-foreground">{dept.total.toLocaleString()}</td>
                      <td className="py-3 px-4 text-center text-success">{dept.resolved.toLocaleString()}</td>
                      <td className="py-3 px-4 text-center text-warning">{dept.pending}</td>
                      <td className="py-3 px-4 text-center text-foreground">{dept.avgTime}</td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant={dept.satisfaction >= 4 ? "default" : "secondary"}>
                          {dept.satisfaction}/5
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={dept.trendDirection === "up" ? "text-success" : "text-destructive"}>
                          {dept.trend}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
