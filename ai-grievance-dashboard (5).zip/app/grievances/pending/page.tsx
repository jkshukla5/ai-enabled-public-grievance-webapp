import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Clock, AlertTriangle, Building2, User, ArrowRight } from "lucide-react"

const pendingComplaints = [
  { id: "GRV-1247", subject: "Power outage in Sector 15 for 48 hours", department: "Electricity", priority: "high", waitTime: "4 hours", citizen: "Ramesh Kumar", aiConfidence: 98.7 },
  { id: "GRV-1245", subject: "Garbage not collected for over a week in Block C", department: "Sanitation", priority: "medium", waitTime: "6 hours", citizen: "John D'souza", aiConfidence: 94.8 },
  { id: "GRV-1242", subject: "Birth certificate pending for 45 days", department: "Public Services", priority: "low", waitTime: "8 hours", citizen: "Meera Devi", aiConfidence: 89.3 },
  { id: "GRV-1251", subject: "Water pressure very low in morning hours", department: "Water Supply", priority: "medium", waitTime: "2 hours", citizen: "Kavita Singh", aiConfidence: 91.2 },
  { id: "GRV-1253", subject: "Broken drainage cover on footpath", department: "Roads & Infra", priority: "high", waitTime: "1 hour", citizen: "Suresh Yadav", aiConfidence: 96.5 },
]

const pendingByDepartment = [
  { name: "Electricity", count: 45, percentage: 29 },
  { name: "Water Supply", count: 38, percentage: 24 },
  { name: "Sanitation", count: 28, percentage: 18 },
  { name: "Roads & Infra", count: 32, percentage: 21 },
  { name: "Public Services", count: 13, percentage: 8 },
]

const priorityStyles = {
  high: "bg-destructive/10 text-destructive border-destructive/20",
  medium: "bg-warning/10 text-warning border-warning/20",
  low: "bg-muted text-muted-foreground border-muted",
}

export default function PendingComplaintsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Pending Complaints</h1>
          <p className="text-muted-foreground">Complaints awaiting department action</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-warning/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Pending</p>
                  <p className="text-2xl font-bold text-foreground">156</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-destructive" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High Priority</p>
                  <p className="text-2xl font-bold text-foreground">24</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-info/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-info" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Wait Time</p>
                  <p className="text-2xl font-bold text-foreground">4.2 hrs</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pending by Department */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base font-medium">
                <Building2 className="w-4 h-4" />
                By Department
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingByDepartment.map((dept) => (
                  <div key={dept.name} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground">{dept.name}</span>
                      <span className="text-muted-foreground">{dept.count}</span>
                    </div>
                    <Progress value={dept.percentage} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Pending Complaints List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recent Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-secondary/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge className={priorityStyles[complaint.priority as keyof typeof priorityStyles]}>
                          {complaint.priority}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {complaint.department}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {complaint.citizen}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Waiting {complaint.waitTime}
                        </span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      View <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
