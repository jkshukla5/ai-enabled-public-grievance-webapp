import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Clock, Star, TrendingUp, ThumbsUp, MessageSquare } from "lucide-react"

const resolvedComplaints = [
  { id: "GRV-1243", subject: "Street lights not working for 2 weeks", department: "Electricity", resolvedBy: "Officer Sharma", resolvedTime: "2.5 hours", satisfaction: 5, date: "2026-05-08" },
  { id: "GRV-1241", subject: "Sewage overflow on main street", department: "Sanitation", resolvedBy: "Officer Verma", resolvedTime: "4 hours", satisfaction: 4, date: "2026-05-07" },
  { id: "GRV-1240", subject: "Water meter showing incorrect readings", department: "Water Supply", resolvedBy: "Officer Singh", resolvedTime: "24 hours", satisfaction: 5, date: "2026-05-07" },
  { id: "GRV-1238", subject: "Transformer sparking dangerously", department: "Electricity", resolvedBy: "Officer Kumar", resolvedTime: "1 hour", satisfaction: 5, date: "2026-05-06" },
  { id: "GRV-1235", subject: "Road repair completed after complaint", department: "Roads & Infra", resolvedBy: "Officer Patel", resolvedTime: "3 days", satisfaction: 4, date: "2026-05-05" },
  { id: "GRV-1232", subject: "Pension document processing completed", department: "Public Services", resolvedBy: "Officer Gupta", resolvedTime: "5 days", satisfaction: 3, date: "2026-05-04" },
]

const resolutionStats = {
  totalResolved: 978,
  avgTime: "2.4 days",
  satisfaction: 4.2,
  autoResolved: 342,
}

const departmentResolution = [
  { name: "Electricity", resolved: 245, avgTime: "1.2 days", rate: 89 },
  { name: "Water Supply", resolved: 198, avgTime: "1.8 days", rate: 82 },
  { name: "Sanitation", resolved: 167, avgTime: "2.1 days", rate: 78 },
  { name: "Roads & Infra", resolved: 212, avgTime: "4.5 days", rate: 71 },
  { name: "Public Services", resolved: 156, avgTime: "5.2 days", rate: 65 },
]

export default function ResolvedComplaintsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Resolved Complaints</h1>
          <p className="text-muted-foreground">Successfully closed citizen grievances</p>
        </div>

        {/* Resolution Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-success/10 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Resolved</p>
                  <p className="text-2xl font-bold text-foreground">{resolutionStats.totalResolved}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-info/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-info" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Resolution</p>
                  <p className="text-2xl font-bold text-foreground">{resolutionStats.avgTime}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-warning/10 flex items-center justify-center">
                  <Star className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Satisfaction</p>
                  <p className="text-2xl font-bold text-foreground">{resolutionStats.satisfaction}/5</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">AI Auto-Resolved</p>
                  <p className="text-2xl font-bold text-foreground">{resolutionStats.autoResolved}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Department Resolution Rates */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">Department Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {departmentResolution.map((dept) => (
                  <div key={dept.name} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground">{dept.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">{dept.resolved}</span>
                        <Badge variant="secondary">{dept.rate}%</Badge>
                      </div>
                    </div>
                    <Progress value={dept.rate} className="h-2" />
                    <p className="text-xs text-muted-foreground">Avg: {dept.avgTime}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Resolved */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base font-medium">Recently Resolved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {resolvedComplaints.map((complaint) => (
                  <div key={complaint.id} className="flex items-start justify-between p-4 bg-success/5 border border-success/20 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span className="font-mono text-sm text-primary">{complaint.id}</span>
                        <Badge variant="outline">{complaint.department}</Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground mb-2">{complaint.subject}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Resolved by: {complaint.resolvedBy}</span>
                        <span>Time: {complaint.resolvedTime}</span>
                        <span>{complaint.date}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {[...Array(complaint.satisfaction)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-warning text-warning" />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  )
}
