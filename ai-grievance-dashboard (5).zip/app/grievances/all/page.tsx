import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Search, Filter, Download, Eye, MoreHorizontal } from "lucide-react"

const complaints = [
  { id: "GRV-1247", subject: "Power outage in Sector 15 for 48 hours", department: "Electricity", status: "pending", priority: "high", date: "2026-05-09", citizen: "Ramesh Kumar", language: "Hindi" },
  { id: "GRV-1246", subject: "No water supply in Gandhi Nagar since 3 days", department: "Water Supply", status: "in-progress", priority: "high", date: "2026-05-09", citizen: "Priya Sharma", language: "Hindi" },
  { id: "GRV-1245", subject: "Garbage not collected for over a week", department: "Sanitation", status: "pending", priority: "medium", date: "2026-05-09", citizen: "John D'souza", language: "English" },
  { id: "GRV-1244", subject: "Large pothole causing accidents near bus stand", department: "Roads & Infra", status: "in-progress", priority: "high", date: "2026-05-08", citizen: "Amit Patel", language: "Hindi" },
  { id: "GRV-1243", subject: "Street lights not working for 2 weeks", department: "Electricity", status: "resolved", priority: "medium", date: "2026-05-08", citizen: "Sarah Wilson", language: "English" },
  { id: "GRV-1242", subject: "Birth certificate pending for 45 days", department: "Public Services", status: "pending", priority: "low", date: "2026-05-08", citizen: "Meera Devi", language: "Hindi" },
  { id: "GRV-1241", subject: "Sewage overflow on main street", department: "Sanitation", status: "resolved", priority: "high", date: "2026-05-07", citizen: "Rajesh Singh", language: "Hindi" },
  { id: "GRV-1240", subject: "Water meter showing incorrect readings", department: "Water Supply", status: "resolved", priority: "medium", date: "2026-05-07", citizen: "Anita Rao", language: "English" },
  { id: "GRV-1239", subject: "Road construction blocking entrance", department: "Roads & Infra", status: "in-progress", priority: "medium", date: "2026-05-06", citizen: "Mohammad Ali", language: "Hindi" },
  { id: "GRV-1238", subject: "Transformer sparking dangerously", department: "Electricity", status: "resolved", priority: "high", date: "2026-05-06", citizen: "Sunita Verma", language: "Hindi" },
]

const statusStyles = {
  pending: "bg-warning/10 text-warning border-warning/20",
  "in-progress": "bg-info/10 text-info border-info/20",
  resolved: "bg-success/10 text-success border-success/20",
}

const priorityStyles = {
  high: "bg-destructive/10 text-destructive",
  medium: "bg-warning/10 text-warning",
  low: "bg-muted text-muted-foreground",
}

export default function AllComplaintsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">All Complaints</h1>
            <p className="text-muted-foreground">View and manage all citizen grievances</p>
          </div>
          <Button>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-medium">Complaints List</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search complaints..." className="pl-9 w-64" />
                </div>
                <Button variant="outline" size="icon">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Citizen</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {complaints.map((complaint) => (
                  <TableRow key={complaint.id}>
                    <TableCell className="font-mono text-sm">{complaint.id}</TableCell>
                    <TableCell className="max-w-xs truncate">{complaint.subject}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{complaint.department}</Badge>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{complaint.citizen}</p>
                        <p className="text-xs text-muted-foreground">{complaint.language}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={statusStyles[complaint.status as keyof typeof statusStyles]}>
                        {complaint.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={priorityStyles[complaint.priority as keyof typeof priorityStyles]}>
                        {complaint.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{complaint.date}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  )
}
