import { PageLayout } from "@/components/dashboard/page-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Clock, Phone, MapPin, User, ArrowRight, Siren } from "lucide-react"

const urgentComplaints = [
  { 
    id: "GRV-1247", 
    subject: "Power outage in Sector 15 - Hospital affected", 
    department: "Electricity", 
    waitTime: "4 hours",
    citizen: "Ramesh Kumar",
    phone: "+91 98765 43210",
    location: "Sector 15, Block A",
    description: "Complete power failure affecting residential area and nearby hospital. Backup generators running low on fuel.",
    aiConfidence: 99.2
  },
  { 
    id: "GRV-1253", 
    subject: "Gas leak reported near school premises", 
    department: "Public Services", 
    waitTime: "1 hour",
    citizen: "Principal Sharma",
    phone: "+91 98765 12345",
    location: "DAV School, Civil Lines",
    description: "Strong gas smell detected near the school kitchen. Classes suspended as precaution.",
    aiConfidence: 98.5
  },
  { 
    id: "GRV-1248", 
    subject: "Major water main burst flooding streets", 
    department: "Water Supply", 
    waitTime: "2 hours",
    citizen: "Municipal Ward Officer",
    phone: "+91 99887 76655",
    location: "MG Road, Near Clock Tower",
    description: "Large water main burst causing significant flooding on main road. Traffic disrupted.",
    aiConfidence: 97.8
  },
  { 
    id: "GRV-1250", 
    subject: "Bridge structural damage reported", 
    department: "Roads & Infra", 
    waitTime: "3 hours",
    citizen: "Traffic Inspector",
    phone: "+91 98112 34567",
    location: "Old Bridge, River Crossing",
    description: "Visible cracks appearing on bridge pillars. Heavy vehicles restricted.",
    aiConfidence: 96.4
  },
]

export default function UrgentComplaintsPage() {
  return (
    <PageLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center">
              <Siren className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Urgent Complaints</h1>
              <p className="text-muted-foreground">High priority issues requiring immediate attention</p>
            </div>
          </div>
          <Badge variant="destructive" className="text-lg px-4 py-2">
            {urgentComplaints.length} Critical
          </Badge>
        </div>

        {/* Urgent Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-destructive/50">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total Urgent</p>
              <p className="text-3xl font-bold text-destructive">24</p>
            </CardContent>
          </Card>
          <Card className="border-warning/50">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Avg. Response Time</p>
              <p className="text-3xl font-bold text-warning">18 min</p>
            </CardContent>
          </Card>
          <Card className="border-success/50">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Resolved Today</p>
              <p className="text-3xl font-bold text-success">12</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Officers Assigned</p>
              <p className="text-3xl font-bold text-foreground">8</p>
            </CardContent>
          </Card>
        </div>

        {/* Urgent Complaints List */}
        <div className="space-y-4">
          {urgentComplaints.map((complaint) => (
            <Card key={complaint.id} className="border-destructive/30">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                      <span className="font-mono text-sm text-primary">{complaint.id}</span>
                      <Badge variant="destructive">URGENT</Badge>
                      <Badge variant="outline">{complaint.department}</Badge>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-foreground mb-2">{complaint.subject}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{complaint.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span className="text-foreground">{complaint.citizen}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                        <span className="text-foreground">{complaint.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span className="text-foreground">{complaint.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-warning font-medium">Waiting {complaint.waitTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-2 ml-4">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">AI Confidence</p>
                      <p className="text-lg font-bold text-primary">{complaint.aiConfidence}%</p>
                    </div>
                    <Button variant="destructive">
                      Take Action <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </PageLayout>
  )
}
